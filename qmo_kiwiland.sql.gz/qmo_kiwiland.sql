-- MySQL dump 10.13  Distrib 5.7.35, for Linux (x86_64)
--
-- Host: localhost    Database: qmo_kiwiland
-- ------------------------------------------------------
-- Server version	5.7.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_adm_configuraciones`
--

DROP TABLE IF EXISTS `tbl_adm_configuraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_adm_configuraciones` (
  `cfg_Id` int(11) NOT NULL,
  `cfg_CheckIn` varchar(5) NOT NULL,
  `cfg_CheckOut` varchar(5) NOT NULL,
  `cfg_LateCheckOut` varchar(5) NOT NULL,
  `cfg_LCOPrecio` int(11) NOT NULL,
  PRIMARY KEY (`cfg_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_adm_configuraciones`
--

LOCK TABLES `tbl_adm_configuraciones` WRITE;
/*!40000 ALTER TABLE `tbl_adm_configuraciones` DISABLE KEYS */;
INSERT INTO `tbl_adm_configuraciones` (`cfg_Id`, `cfg_CheckIn`, `cfg_CheckOut`, `cfg_LateCheckOut`, `cfg_LCOPrecio`) VALUES (1,'15:00','12:00','17:00',33000);
/*!40000 ALTER TABLE `tbl_adm_configuraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_adm_modulos`
--

DROP TABLE IF EXISTS `tbl_adm_modulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_adm_modulos` (
  `modulo_Id` int(11) NOT NULL AUTO_INCREMENT,
  `modulo_Nombre` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `modulo_Sigla` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`modulo_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_adm_modulos`
--

LOCK TABLES `tbl_adm_modulos` WRITE;
/*!40000 ALTER TABLE `tbl_adm_modulos` DISABLE KEYS */;
INSERT INTO `tbl_adm_modulos` (`modulo_Id`, `modulo_Nombre`, `modulo_Sigla`) VALUES (1,'Reservas','RES'),(2,'Ingresos/Egresos','INGEGR'),(3,'Maestros','MAE'),(4,'Mantenedores','MAN'),(5,'Administración','ADM');
/*!40000 ALTER TABLE `tbl_adm_modulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_adm_permisos`
--

DROP TABLE IF EXISTS `tbl_adm_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_adm_permisos` (
  `usuario_Id` int(11) NOT NULL,
  `modulo_Id` int(11) NOT NULL,
  `permiso_Crear` enum('A','I') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'I' COMMENT 'A=ACTIVO/I=INACTIVO/D=DESACTIVADO(NO CORRE PARA EL MODULO EN CUESTION)',
  `permiso_Leer` enum('A','I') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'I' COMMENT 'A=ACTIVO/I=INACTIVO/D=DESACTIVADO(NO CORRE PARA EL MODULO EN CUESTION)',
  `permiso_Actualizar` enum('A','I') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'I' COMMENT 'A=ACTIVO/I=INACTIVO/D=DESACTIVADO(NO CORRE PARA EL MODULO EN CUESTION)',
  `permiso_Eliminar` enum('A','I') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'I' COMMENT 'A=ACTIVO/I=INACTIVO/D=DESACTIVADO(NO CORRE PARA EL MODULO EN CUESTION)',
  `permiso_Pagar` enum('A','I') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'I',
  PRIMARY KEY (`usuario_Id`,`modulo_Id`),
  KEY `fk_tbl_adm_Usuarios_has_tbl_adm_Modulos_tbl_adm_Modulos1_idx` (`modulo_Id`),
  KEY `fk_tbl_adm_Usuarios_has_tbl_adm_Modulos_tbl_adm_Usuarios1_idx` (`usuario_Id`),
  CONSTRAINT `fk_tbl_adm_Usuarios_has_tbl_adm_Modulos_tbl_adm_Modulos1` FOREIGN KEY (`modulo_Id`) REFERENCES `tbl_adm_modulos` (`modulo_Id`),
  CONSTRAINT `fk_tbl_adm_Usuarios_has_tbl_adm_Modulos_tbl_adm_Usuarios1` FOREIGN KEY (`usuario_Id`) REFERENCES `tbl_adm_usuarios` (`usuario_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_adm_permisos`
--

LOCK TABLES `tbl_adm_permisos` WRITE;
/*!40000 ALTER TABLE `tbl_adm_permisos` DISABLE KEYS */;
INSERT INTO `tbl_adm_permisos` (`usuario_Id`, `modulo_Id`, `permiso_Crear`, `permiso_Leer`, `permiso_Actualizar`, `permiso_Eliminar`, `permiso_Pagar`) VALUES (3,1,'A','A','A','A','A'),(3,2,'A','A','A','A','I'),(3,3,'A','A','A','A','I'),(3,4,'A','A','A','A','I'),(3,5,'A','A','A','A','I'),(5,1,'A','A','A','I','A'),(5,2,'A','A','A','I','I'),(5,3,'A','A','A','I','I');
/*!40000 ALTER TABLE `tbl_adm_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_adm_usuarios`
--

DROP TABLE IF EXISTS `tbl_adm_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_adm_usuarios` (
  `usuario_Id` int(11) NOT NULL AUTO_INCREMENT,
  `funcionario_Id` int(11) NOT NULL,
  `usuario_Nombre` varchar(20) NOT NULL,
  `usuario_Contrasena` varchar(60) NOT NULL,
  `usuario_Nivel` enum('USU','ADM') NOT NULL DEFAULT 'USU',
  `usuario_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`usuario_Id`,`funcionario_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_adm_usuarios`
--

LOCK TABLES `tbl_adm_usuarios` WRITE;
/*!40000 ALTER TABLE `tbl_adm_usuarios` DISABLE KEYS */;
INSERT INTO `tbl_adm_usuarios` (`usuario_Id`, `funcionario_Id`, `usuario_Nombre`, `usuario_Contrasena`, `usuario_Nivel`, `usuario_Estado`) VALUES (2,5,'admin','8c65a1a733aaea1cefea31b3d8821724','ADM','A'),(3,6,'vlarap','768e357eecb07f6419b303eaf4c89a58','ADM','A'),(4,7,'javiera','7055c0b2e76a6b8f40704b88956e48ac','ADM','A'),(5,8,'prueba','fa5a02c9cc183b3ff1bfcd4c2243f85c','USU','A');
/*!40000 ALTER TABLE `tbl_adm_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_con_egresoccosto`
--

DROP TABLE IF EXISTS `tbl_con_egresoccosto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_con_egresoccosto` (
  `egresoCC_Id` int(11) NOT NULL AUTO_INCREMENT,
  `egreso_Id` int(11) NOT NULL,
  `cCosto_Id` int(11) NOT NULL,
  `egresoCC_Monto` bigint(20) NOT NULL,
  PRIMARY KEY (`egresoCC_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_con_egresoccosto`
--

LOCK TABLES `tbl_con_egresoccosto` WRITE;
/*!40000 ALTER TABLE `tbl_con_egresoccosto` DISABLE KEYS */;
INSERT INTO `tbl_con_egresoccosto` (`egresoCC_Id`, `egreso_Id`, `cCosto_Id`, `egresoCC_Monto`) VALUES (1,1,2,105938),(3,3,2,208509),(4,2,2,249120),(8,4,1,12000),(9,5,2,55940),(10,6,2,105878),(11,7,1,45000),(12,8,2,51940),(13,9,2,51940),(14,10,2,51940),(15,11,2,51940),(16,12,2,51940),(17,13,2,105940),(18,14,2,320289),(19,15,2,27191),(20,16,2,27191),(21,17,2,27191),(22,18,2,27191),(23,19,2,27191),(24,20,2,27191),(25,21,2,27191),(26,22,1,49990),(27,23,1,20000),(28,24,1,4600),(29,25,1,6000),(30,26,1,20000);
/*!40000 ALTER TABLE `tbl_con_egresoccosto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_con_egresos`
--

DROP TABLE IF EXISTS `tbl_con_egresos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_con_egresos` (
  `egreso_Id` int(11) NOT NULL AUTO_INCREMENT,
  `egreso_NroDoc` int(11) NOT NULL,
  `egreso_Fecha` date NOT NULL,
  `tipoDoc_Id` int(11) NOT NULL,
  `categoria_Id` int(11) NOT NULL,
  `cliente_Id` int(11) NOT NULL,
  `egreso_Comentario` text,
  `egreso_Estado` enum('I','A') NOT NULL DEFAULT 'I',
  `egreso_UsuarioCrea` int(11) NOT NULL,
  `egreso_FechaCrea` datetime NOT NULL,
  `egreso_UsuarioModifica` int(11) NOT NULL,
  `egreso_FechaModifica` datetime NOT NULL,
  PRIMARY KEY (`egreso_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_con_egresos`
--

LOCK TABLES `tbl_con_egresos` WRITE;
/*!40000 ALTER TABLE `tbl_con_egresos` DISABLE KEYS */;
INSERT INTO `tbl_con_egresos` (`egreso_Id`, `egreso_NroDoc`, `egreso_Fecha`, `tipoDoc_Id`, `categoria_Id`, `cliente_Id`, `egreso_Comentario`, `egreso_Estado`, `egreso_UsuarioCrea`, `egreso_FechaCrea`, `egreso_UsuarioModifica`, `egreso_FechaModifica`) VALUES (1,6833593,'2020-10-15',1,12,5,'Factura WOM ','I',4,'2020-10-28 10:05:36',4,'2020-10-28 10:05:36'),(2,1,'2020-11-10',1,9,10,'Imposiciones','I',4,'2020-11-10 17:14:39',4,'2020-11-19 09:37:09'),(3,2,'2020-11-19',1,10,10,'IVA mes de Octubre ','I',4,'2020-11-19 09:36:34',4,'2020-11-19 09:36:34'),(4,4,'2020-12-01',1,1,10,'Sodicmac','I',4,'2020-12-08 19:54:07',4,'2020-12-08 19:55:44'),(5,2,'2020-12-28',1,11,10,'Tu ves','I',4,'2020-12-28 10:38:26',4,'2020-12-28 10:38:26'),(6,3,'2020-12-28',1,12,10,'Factura WOM ','I',4,'2020-12-28 10:39:06',4,'2020-12-28 10:39:06'),(7,3,'2021-01-04',3,7,10,'Remuneracion por dias trabajados blanca','I',4,'2021-01-04 10:04:27',4,'2021-01-04 10:04:27'),(8,1,'2021-01-28',1,11,10,'','I',4,'2021-01-28 11:07:10',4,'2021-01-28 11:07:10'),(9,2,'2021-01-28',1,12,10,'','I',4,'2021-01-28 11:07:54',4,'2021-01-28 11:07:54'),(10,3,'2021-02-19',1,11,10,'','I',4,'2021-02-19 13:48:06',4,'2021-02-19 13:48:06'),(11,3,'2021-02-19',1,11,10,'','I',4,'2021-02-19 13:48:06',4,'2021-02-19 13:48:06'),(12,3,'2021-02-19',1,11,10,'','I',4,'2021-02-19 13:48:15',4,'2021-02-19 13:48:15'),(13,2,'2021-02-19',1,12,10,'','I',4,'2021-02-19 13:49:04',4,'2021-02-19 13:49:04'),(14,22021,'2021-03-09',1,9,10,'Imposiciones correspondientes a Febrero ','I',4,'2021-03-15 09:44:41',4,'2021-03-15 09:44:41'),(15,1903,'2021-03-17',1,10,10,' IVA correspondiente a Febrero','I',4,'2021-03-18 09:35:21',4,'2021-03-18 09:35:21'),(16,1903,'2021-03-17',1,10,10,' IVA correspondiente a Febrero','A',4,'2021-03-18 09:35:21',4,'2021-03-18 09:35:21'),(17,1903,'2021-03-17',1,10,10,' IVA correspondiente a Febrero','A',4,'2021-03-18 09:35:22',4,'2021-03-18 09:35:22'),(18,1903,'2021-03-17',1,10,10,' IVA correspondiente a Febrero','A',4,'2021-03-18 09:35:22',4,'2021-03-18 09:35:22'),(19,1903,'2021-03-17',1,10,10,' IVA correspondiente a Febrero','A',4,'2021-03-18 09:35:22',4,'2021-03-18 09:35:22'),(20,1903,'2021-03-17',1,10,10,' IVA correspondiente a Febrero','A',4,'2021-03-18 09:35:23',4,'2021-03-18 09:35:23'),(21,1903,'2021-03-17',1,10,10,' IVA correspondiente a Febrero','A',4,'2021-03-18 09:35:32',4,'2021-03-18 09:35:32'),(22,1183487,'2021-10-02',3,1,10,'Compra de cobertores cannon ','I',4,'2021-10-02 20:30:39',4,'2021-10-02 20:30:39'),(23,0,'2021-10-01',3,7,10,' Delia apoyo viernes ','I',4,'2021-10-02 20:31:30',4,'2021-10-02 20:31:30'),(24,0,'2021-10-02',3,1,10,' dos cloros grandes','I',4,'2021-10-02 20:39:08',4,'2021-10-02 20:39:08'),(25,0,'2021-10-02',3,1,10,'','I',4,'2021-10-02 20:46:28',4,'2021-10-02 20:46:28'),(26,2,'2021-10-05',3,7,10,'Pago por apoyo  delia ','I',4,'2021-10-05 21:37:15',4,'2021-10-05 21:37:15');
/*!40000 ALTER TABLE `tbl_con_egresos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_con_ingresos`
--

DROP TABLE IF EXISTS `tbl_con_ingresos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_con_ingresos` (
  `ingreso_Id` int(11) NOT NULL AUTO_INCREMENT,
  `reserva_Id` int(11) NOT NULL,
  `ingreso_Fecha` date NOT NULL,
  `tipoDoc_Id` int(11) NOT NULL,
  `medioPago_Id` int(11) NOT NULL,
  `categoria_Id` int(11) NOT NULL,
  `ingreso_Monto` bigint(20) NOT NULL,
  `ingreso_Comentario` text,
  `ingreso_Estado` enum('I','A','C') NOT NULL DEFAULT 'I',
  `ingreso_UsuarioCrea` int(11) NOT NULL,
  `ingreso_FechaCrea` datetime NOT NULL,
  `ingreso_UsuarioModifica` int(11) NOT NULL,
  `ingreso_FechaModifica` datetime NOT NULL,
  PRIMARY KEY (`ingreso_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_con_ingresos`
--

LOCK TABLES `tbl_con_ingresos` WRITE;
/*!40000 ALTER TABLE `tbl_con_ingresos` DISABLE KEYS */;
INSERT INTO `tbl_con_ingresos` (`ingreso_Id`, `reserva_Id`, `ingreso_Fecha`, `tipoDoc_Id`, `medioPago_Id`, `categoria_Id`, `ingreso_Monto`, `ingreso_Comentario`, `ingreso_Estado`, `ingreso_UsuarioCrea`, `ingreso_FechaCrea`, `ingreso_UsuarioModifica`, `ingreso_FechaModifica`) VALUES (1,3,'2020-10-13',4,2,2,250000,'Abono correspondiente a la reserva total pendiente de pago $226.000','I',4,'2020-10-25 12:17:25',4,'2020-10-25 12:17:25'),(2,2,'2020-10-13',4,2,2,250,'Abono correspondiente al total de la reserva, pendiente de pago $226.000','I',4,'2020-10-25 12:18:22',4,'2020-10-25 12:18:22'),(3,7,'2020-11-03',4,2,2,50000,'abono de reserva ','I',4,'2020-11-03 09:48:08',4,'2020-11-03 09:48:08'),(4,7,'2020-11-02',4,2,2,50000,' abono de reserva ','I',4,'2020-11-03 09:48:42',4,'2020-11-03 09:48:42'),(5,11,'2020-11-11',4,2,2,55000,' abono el 50%','I',4,'2020-11-11 09:36:45',4,'2020-11-11 09:36:45'),(6,2,'2020-11-05',4,2,4,150000,'','I',4,'2020-11-16 08:37:25',4,'2020-11-16 08:37:25'),(7,19,'2020-12-07',4,2,2,85000,'85000 Abono el 50% de la reserva','C',4,'2020-12-08 19:38:34',4,'2021-01-04 09:39:35'),(8,21,'2020-12-07',4,2,2,75000,'Abono el 50% correspondiente al total de la reserva','C',4,'2020-12-08 19:39:22',4,'2021-01-04 09:38:42'),(9,24,'2020-12-06',4,2,2,55000,'Abono el 50% de la reserva debe 55.000','I',4,'2020-12-08 19:43:59',4,'2020-12-08 19:43:59'),(10,25,'2020-12-06',4,2,2,55000,'Abono el 50%','I',4,'2020-12-08 19:45:58',4,'2020-12-08 19:45:58'),(11,27,'2020-12-10',4,2,2,55000,'Abono el 50%','C',4,'2020-12-10 20:31:18',4,'2020-12-15 15:17:13'),(12,28,'2020-12-10',4,2,2,75000,'Abono el 50%','I',4,'2020-12-11 09:12:22',4,'2020-12-11 09:12:22'),(13,27,'2020-12-13',4,2,2,10000,'','C',4,'2020-12-14 09:32:47',4,'2020-12-15 15:17:10'),(14,29,'2020-12-14',4,2,2,65000,'','C',4,'2020-12-14 19:22:00',4,'2020-12-15 15:16:55'),(15,31,'2020-12-15',4,2,2,90000,'Abono del 50% por tres noches ','C',4,'2020-12-15 15:12:14',4,'2020-12-15 15:15:30'),(16,32,'2020-12-15',4,2,2,82500,'Abono 82.500 debe 82.500','C',4,'2020-12-15 15:15:20',4,'2020-12-15 15:16:21'),(17,31,'2020-12-15',4,2,2,7500,'diferencia de abono solo pendiente 97500','C',4,'2020-12-15 15:16:08',4,'2020-12-15 15:16:34'),(18,33,'2020-12-16',4,2,2,65000,'Abono 65000 debe 65000','C',4,'2020-12-17 10:57:33',4,'2020-12-17 10:58:09'),(19,34,'2020-12-18',4,2,2,55000,' Abono del 50%','C',4,'2020-12-19 12:08:43',4,'2020-12-19 12:08:50'),(20,33,'2020-12-18',4,2,2,65000,'','C',4,'2020-12-19 12:10:38',4,'2020-12-19 12:10:45'),(21,29,'2020-12-18',4,2,2,65000,'','C',4,'2020-12-19 12:12:05',4,'2020-12-19 12:12:13'),(22,27,'2020-12-18',4,2,2,65000,'','C',4,'2020-12-19 12:12:48',4,'2020-12-19 12:12:59'),(23,35,'2020-12-21',4,2,2,55000,'Abono el 50%','I',4,'2020-12-21 20:27:56',4,'2020-12-21 20:27:56'),(24,35,'2020-12-21',4,2,2,55000,'Abono el 50%','I',4,'2020-12-21 20:27:56',4,'2020-12-21 20:27:56'),(25,36,'2020-12-21',4,2,2,55000,'Abono el 50%','I',4,'2020-12-21 20:31:46',4,'2020-12-21 20:31:46'),(26,32,'2021-01-01',4,2,2,82500,'','C',4,'2021-01-04 09:36:17',4,'2021-01-04 09:36:25'),(27,31,'2021-01-01',4,2,2,97500,'','C',4,'2021-01-04 09:37:03',4,'2021-01-04 09:41:04'),(28,21,'2021-01-01',4,2,2,75000,'','C',4,'2021-01-04 09:38:33',4,'2021-01-04 09:38:39'),(29,19,'2021-01-04',4,2,2,85000,'','C',4,'2021-01-04 09:39:55',4,'2021-01-04 09:40:05'),(30,39,'2021-01-03',4,2,4,170000,'','C',4,'2021-01-04 09:44:39',4,'2021-01-04 09:44:46'),(31,40,'2021-01-02',4,2,2,65000,'65000','C',4,'2021-01-04 17:13:24',4,'2021-01-04 17:13:30'),(32,46,'2021-01-04',4,2,2,27500,'','C',4,'2021-01-04 20:45:34',4,'2021-01-04 20:45:40'),(33,42,'2021-01-03',4,2,4,95000,'','C',4,'2021-01-05 08:29:33',4,'2021-01-05 08:29:39'),(34,43,'2021-01-04',4,2,4,65000,'','C',4,'2021-01-05 08:38:02',4,'2021-01-05 08:38:09'),(35,45,'2021-01-04',4,2,4,55000,'','C',4,'2021-01-05 08:38:47',4,'2021-01-05 08:38:53'),(36,50,'2021-01-04',4,2,2,97500,' Abono el 50% debe 97500','C',4,'2021-01-05 08:44:49',4,'2021-01-05 08:44:55'),(37,51,'2021-01-05',4,2,2,100000,'Abono 100.000 debe 95.000','C',4,'2021-01-05 22:10:25',4,'2021-01-05 22:10:31'),(38,52,'2021-01-05',4,2,4,55000,'','C',4,'2021-01-05 22:15:22',4,'2021-01-05 22:15:28'),(39,46,'2021-01-05',4,2,2,27500,'','C',4,'2021-01-06 10:15:24',4,'2021-01-06 10:15:31'),(40,54,'2021-01-07',4,2,4,110000,'','C',4,'2021-01-07 09:17:14',4,'2021-01-07 09:17:29'),(41,56,'2021-01-06',4,2,2,65000,'Abono 65.000 debe 100.000','C',4,'2021-01-07 09:31:49',4,'2021-01-07 09:31:54'),(42,57,'2021-01-07',4,2,2,55000,'Abono el 50% debe  $55.000','C',4,'2021-01-07 16:17:10',4,'2021-01-07 16:17:15'),(43,59,'2021-01-08',4,2,2,55000,'debe 55.000','C',4,'2021-01-08 10:04:34',4,'2021-01-08 10:04:39'),(44,58,'2021-01-08',4,2,4,55000,'','C',4,'2021-01-08 10:37:22',4,'2021-01-08 10:37:31'),(45,60,'2021-01-07',4,2,2,82500,' debe 82500','C',4,'2021-01-08 11:23:41',4,'2021-01-08 11:23:52'),(46,61,'2021-01-07',4,2,2,82500,'debe 82500','I',4,'2021-01-08 11:26:17',4,'2021-01-08 11:26:17'),(47,57,'2021-01-09',4,2,2,65000,' Motivo anulación: duplicado','A',4,'2021-01-09 18:14:51',4,'2021-01-09 18:16:10'),(48,57,'2021-01-09',4,2,2,65000,'','C',4,'2021-01-09 18:14:52',4,'2021-01-09 18:16:13'),(49,62,'2021-01-09',4,2,4,55000,'','C',4,'2021-01-09 18:16:42',4,'2021-01-09 18:16:48'),(50,47,'2021-01-09',4,2,4,110000,'','I',4,'2021-01-09 18:17:16',4,'2021-01-09 18:17:16'),(51,63,'2021-01-09',4,2,2,85000,'','I',4,'2021-01-09 18:24:27',4,'2021-01-09 18:24:27'),(52,64,'2021-01-09',4,2,2,85000,'debe 85000','C',4,'2021-01-09 18:25:51',4,'2021-01-09 18:25:56'),(53,68,'2021-01-10',4,2,2,32500,'','C',4,'2021-01-10 10:12:58',4,'2021-01-11 09:46:20'),(54,67,'2021-01-10',4,2,2,32500,'','C',4,'2021-01-10 10:13:15',4,'2021-01-11 09:45:40'),(55,67,'2021-01-11',4,2,2,32500,'','C',4,'2021-01-11 09:45:31',4,'2021-01-11 09:45:37'),(56,68,'2021-01-11',4,2,2,32500,'','C',4,'2021-01-11 09:46:11',4,'2021-01-11 09:46:17'),(57,69,'2021-01-10',4,2,2,55000,'','C',4,'2021-01-11 09:53:02',4,'2021-01-14 16:54:55'),(58,70,'2021-01-10',4,2,2,170000,'','C',4,'2021-01-11 09:55:30',4,'2021-01-13 15:53:18'),(59,72,'2021-01-11',4,2,2,55000,'','C',4,'2021-01-11 10:00:20',4,'2021-01-22 12:37:51'),(60,73,'2021-01-07',4,2,2,82500,'','C',4,'2021-01-11 16:30:26',4,'2021-01-14 16:53:51'),(61,70,'2021-01-12',4,2,2,170000,'','C',4,'2021-01-13 15:53:34',4,'2021-01-13 15:53:41'),(62,75,'2021-01-11',4,2,2,82500,'','C',4,'2021-01-13 16:00:27',4,'2021-01-18 10:29:47'),(63,74,'2021-01-13',4,2,2,55000,'','C',4,'2021-01-13 16:00:54',4,'2021-01-18 10:30:07'),(64,50,'2021-01-13',4,2,2,97500,'','C',4,'2021-01-13 16:01:27',4,'2021-01-13 16:01:35'),(65,76,'2021-01-13',4,2,4,110000,'','C',4,'2021-01-13 16:06:31',4,'2021-01-13 16:06:36'),(66,77,'2021-01-14',4,2,2,55000,'','C',4,'2021-01-14 16:53:07',4,'2021-01-18 10:29:08'),(67,73,'2021-01-14',4,2,2,82500,'','C',4,'2021-01-14 16:53:31',4,'2021-01-14 16:53:56'),(68,69,'2021-01-14',4,2,2,55000,'','C',4,'2021-01-14 16:54:50',4,'2021-01-14 16:54:58'),(69,77,'2021-01-18',4,2,2,55000,'','C',4,'2021-01-18 10:29:00',4,'2021-01-18 10:29:05'),(70,75,'2021-01-18',4,2,2,82500,'','C',4,'2021-01-18 10:29:40',4,'2021-01-18 10:29:51'),(71,74,'2021-01-18',4,2,2,55000,'','C',4,'2021-01-18 10:30:19',4,'2021-01-18 10:30:24'),(72,78,'2021-01-17',4,2,2,27500,'','C',4,'2021-01-18 10:36:34',4,'2021-01-22 12:38:55'),(73,79,'2021-01-18',4,2,2,75000,'','I',4,'2021-01-18 12:11:43',4,'2021-01-18 12:11:43'),(74,72,'2021-01-20',4,2,4,112000,'','C',4,'2021-01-22 12:38:22',4,'2021-01-22 12:38:28'),(75,78,'2021-01-20',4,2,2,27500,'','C',4,'2021-01-22 12:39:27',4,'2021-01-22 12:39:33'),(76,83,'2021-01-22',4,2,4,55000,'','C',4,'2021-01-22 12:43:02',4,'2021-01-22 12:43:09'),(77,84,'2021-01-18',4,2,13,16000,'','C',4,'2021-01-22 12:45:53',4,'2021-01-22 12:45:58'),(78,90,'2021-01-27',4,2,2,205000,'','I',4,'2021-01-28 11:20:09',4,'2021-01-28 11:20:09'),(79,91,'2021-02-01',4,2,2,65000,'','I',4,'2021-02-01 11:39:16',4,'2021-02-01 11:39:16'),(80,92,'2021-02-03',4,2,2,130000,'','C',4,'2021-02-03 11:29:31',4,'2021-02-06 13:17:16'),(81,94,'2021-02-02',4,2,4,165000,'','C',4,'2021-02-03 11:36:36',4,'2021-02-03 11:36:43'),(82,93,'2021-02-02',4,2,2,55000,'','C',4,'2021-02-03 11:37:08',4,'2021-02-08 14:28:47'),(83,92,'2021-02-06',4,2,2,130000,'','C',4,'2021-02-06 13:17:05',4,'2021-02-06 13:17:12'),(84,93,'2021-02-07',4,1,2,55000,'','C',4,'2021-02-08 14:28:29',4,'2021-02-08 14:28:43'),(85,95,'2021-02-08',4,2,4,55000,'','C',4,'2021-02-08 14:35:54',4,'2021-02-08 14:36:02'),(86,96,'2021-02-04',4,2,2,55000,'','C',4,'2021-02-08 14:39:05',4,'2021-02-08 14:40:48'),(87,97,'2021-02-08',4,2,2,55000,'','I',4,'2021-02-08 14:43:16',4,'2021-02-08 14:43:16'),(88,99,'2021-02-03',4,2,2,55000,'','C',4,'2021-02-08 14:49:10',4,'2021-02-17 11:03:42'),(89,98,'2021-02-03',4,2,2,67500,'debe 67500 inlcuyendo el late check out','C',4,'2021-02-08 14:50:44',4,'2021-02-17 11:01:43'),(90,100,'2021-02-07',4,2,2,55000,'','C',4,'2021-02-08 14:53:25',4,'2021-02-08 14:53:41'),(91,102,'2021-02-09',4,2,2,55000,'','C',4,'2021-02-09 17:42:35',4,'2021-02-17 11:00:12'),(92,101,'2021-02-09',4,2,2,55000,'','C',4,'2021-02-09 17:43:10',4,'2021-02-17 11:06:08'),(93,96,'2021-02-10',4,2,2,55000,'','C',4,'2021-02-11 11:24:26',4,'2021-02-11 11:24:37'),(94,103,'2021-02-10',4,2,2,55000,'','C',4,'2021-02-11 11:27:26',4,'2021-02-19 13:21:11'),(95,104,'2021-02-09',4,2,2,55000,'','C',4,'2021-02-11 11:35:15',4,'2021-02-28 21:01:42'),(96,105,'2021-02-11',4,2,2,55000,'','C',4,'2021-02-11 17:23:17',4,'2021-02-17 10:58:04'),(97,105,'2021-02-16',4,2,2,55000,'','C',4,'2021-02-17 10:58:23',4,'2021-02-17 10:58:39'),(98,102,'2021-02-16',4,2,2,55000,'','C',4,'2021-02-17 10:59:57',4,'2021-02-17 11:00:15'),(99,98,'2021-02-17',4,2,2,67500,'','C',4,'2021-02-17 11:01:36',4,'2021-02-17 11:01:48'),(100,99,'2021-02-17',4,2,2,55000,'','C',4,'2021-02-17 11:03:30',4,'2021-02-17 11:03:50'),(101,100,'2021-02-17',4,2,4,110000,'','C',4,'2021-02-17 11:04:45',4,'2021-02-17 11:04:54'),(102,101,'2021-02-16',4,2,2,55000,'','C',4,'2021-02-17 11:05:54',4,'2021-02-17 11:06:12'),(103,106,'2021-02-17',4,2,4,110000,'','C',4,'2021-02-17 11:18:46',4,'2021-02-17 11:18:52'),(104,103,'2021-02-18',4,2,2,55000,'','C',4,'2021-02-19 13:21:29',4,'2021-02-19 13:21:40'),(105,107,'2021-02-18',4,2,4,110000,'','C',4,'2021-02-19 13:22:37',4,'2021-02-19 13:22:43'),(106,115,'2021-02-23',4,2,4,110000,'','C',4,'2021-02-24 12:34:16',4,'2021-02-24 12:34:23'),(107,112,'2021-02-23',4,2,4,255000,' Motivo anulación: error de ingreso','A',4,'2021-02-24 12:36:05',4,'2021-02-24 12:37:03'),(108,112,'2021-02-23',4,2,4,190000,'','C',4,'2021-02-24 12:37:32',4,'2021-02-24 12:38:02'),(109,112,'2021-02-24',4,2,13,18000,'','C',4,'2021-02-24 12:37:52',4,'2021-02-24 12:37:58'),(110,110,'2021-02-24',4,2,4,130000,'','C',4,'2021-02-24 12:38:34',4,'2021-02-24 12:38:42'),(111,109,'2021-02-24',4,2,4,130000,'','C',4,'2021-02-24 12:40:51',4,'2021-02-24 12:40:58'),(112,124,'2021-02-24',4,2,4,170000,'','C',4,'2021-02-24 12:45:02',4,'2021-02-24 12:45:10'),(113,125,'2021-02-24',4,2,4,170000,'','C',4,'2021-02-24 12:45:53',4,'2021-02-24 12:45:59'),(114,126,'2021-02-24',4,2,4,130000,'','C',4,'2021-02-24 12:46:46',4,'2021-02-24 12:47:01'),(115,113,'2021-02-23',4,2,4,110000,'','C',4,'2021-02-24 12:47:31',4,'2021-02-24 12:47:38'),(116,114,'2021-02-23',4,2,4,110000,'','C',4,'2021-02-24 12:48:25',4,'2021-02-24 12:48:32'),(117,120,'2021-02-26',4,2,4,110000,'','C',4,'2021-02-28 10:16:02',4,'2021-02-28 10:16:09'),(118,119,'2021-02-25',4,2,4,110000,'','C',4,'2021-02-28 10:17:03',4,'2021-02-28 10:17:15'),(119,118,'2021-02-25',4,2,4,110000,'','C',4,'2021-02-28 10:18:18',4,'2021-02-28 10:18:45'),(120,117,'2021-02-26',4,2,4,110000,'','C',4,'2021-02-28 10:19:37',4,'2021-02-28 10:20:23'),(121,116,'2021-02-26',4,2,4,110000,'','C',4,'2021-02-28 10:21:05',4,'2021-02-28 10:21:20'),(122,137,'2021-02-27',4,2,4,130000,'','C',4,'2021-02-28 20:58:05',4,'2021-02-28 20:58:12'),(123,132,'2021-02-26',4,2,4,110000,'','C',4,'2021-02-28 20:58:46',4,'2021-02-28 20:58:54'),(124,131,'2021-02-27',4,2,4,190000,'','C',4,'2021-02-28 20:59:24',4,'2021-02-28 20:59:31'),(125,127,'2021-02-27',4,2,4,165000,'','C',4,'2021-02-28 21:01:03',4,'2021-02-28 21:01:17'),(126,104,'2021-02-26',4,2,4,55000,'','C',4,'2021-02-28 21:02:02',4,'2021-02-28 21:02:10'),(127,121,'2021-02-27',4,2,4,165000,'','C',4,'2021-02-28 21:03:53',4,'2021-02-28 21:04:00'),(128,134,'2021-03-01',4,2,4,260000,'','C',4,'2021-03-02 12:23:44',4,'2021-03-02 12:23:51'),(129,141,'2021-03-01',4,2,3,25000,'','C',4,'2021-03-02 12:25:01',4,'2021-03-02 12:25:08'),(130,142,'2021-03-03',4,1,4,55000,'','C',4,'2021-03-04 09:31:15',4,'2021-03-04 09:31:24'),(131,140,'2021-03-03',4,1,4,110000,'','C',4,'2021-03-04 09:32:18',4,'2021-03-04 09:32:36'),(132,139,'2021-03-03',4,2,4,110000,'','C',4,'2021-03-04 09:33:26',4,'2021-03-04 09:34:27'),(133,129,'2021-03-03',4,2,4,330000,'','I',4,'2021-03-04 09:37:14',4,'2021-03-04 09:37:14'),(134,135,'2021-03-13',4,2,4,110000,'','C',4,'2021-03-08 09:08:54',4,'2021-03-08 09:09:05'),(135,138,'2021-03-12',4,2,2,110000,'','C',4,'2021-03-12 10:13:27',4,'2021-03-12 10:13:37'),(136,146,'2021-04-06',4,1,4,165000,'','C',4,'2021-04-06 21:19:19',4,'2021-04-09 13:04:08'),(137,145,'2021-04-06',4,2,2,50000,'Saldo pendiente 130.000','C',4,'2021-04-06 21:21:17',4,'2021-04-09 13:05:05'),(138,144,'2021-04-04',4,2,2,55000,'pendiente el 50%','C',4,'2021-04-06 21:22:14',4,'2021-04-09 13:06:09'),(139,143,'2021-04-01',4,2,2,50000,'pendiente 60.000','C',4,'2021-04-06 21:23:52',4,'2021-04-11 23:07:35'),(140,147,'2021-04-08',4,2,2,100000,'debe 150.000 ya que tiene 3 adicionales','C',4,'2021-04-09 13:03:40',4,'2021-04-11 23:06:52'),(141,145,'2021-04-09',4,2,2,130000,'','C',4,'2021-04-09 13:04:50',4,'2021-04-09 13:05:00'),(142,144,'2021-04-08',4,1,2,55000,'','C',4,'2021-04-09 13:05:56',4,'2021-04-09 13:06:04'),(143,149,'2021-04-09',4,1,4,200000,'','C',4,'2021-04-11 23:05:36',4,'2021-04-11 23:05:43'),(144,147,'2021-04-11',4,2,2,150000,'','C',4,'2021-04-11 23:06:42',4,'2021-04-11 23:06:48'),(145,143,'2021-04-11',4,2,2,60000,'','C',4,'2021-04-11 23:07:25',4,'2021-04-11 23:07:31'),(146,151,'2021-04-14',4,2,2,30000,'debe 75000','I',4,'2021-04-15 10:21:10',4,'2021-04-15 10:21:10'),(147,150,'2021-04-14',4,2,2,50000,'','C',4,'2021-04-15 10:21:32',4,'2021-04-18 21:25:19'),(148,152,'2021-04-16',4,1,4,120000,'','C',4,'2021-04-18 21:24:26',4,'2021-04-18 21:24:32'),(149,150,'2021-04-17',4,1,4,110000,'60000','C',4,'2021-04-18 21:25:07',4,'2021-04-18 21:25:14'),(150,153,'2021-04-17',4,2,4,130000,'','C',4,'2021-04-18 21:29:01',4,'2021-04-18 21:29:09'),(151,154,'2021-04-20',4,2,2,85000,'','C',4,'2021-04-20 18:48:25',4,'2021-04-25 11:57:20'),(152,155,'2021-04-23',4,1,4,280000,'','C',4,'2021-04-23 09:28:26',4,'2021-04-25 11:56:36'),(153,154,'2021-04-24',4,2,2,85000,'','C',4,'2021-04-25 11:57:10',4,'2021-04-25 11:57:16'),(154,148,'2021-04-24',4,2,4,110000,'','C',4,'2021-04-25 11:57:54',4,'2021-04-25 11:58:01'),(155,156,'2021-04-25',4,2,4,110000,'','C',4,'2021-04-25 11:59:14',4,'2021-04-25 11:59:22'),(156,162,'2021-04-27',4,2,2,55000,'','C',4,'2021-04-28 10:29:44',4,'2021-05-02 16:32:52'),(157,161,'2021-04-27',4,2,2,55000,'','C',4,'2021-04-28 10:30:04',4,'2021-05-02 16:33:31'),(158,160,'2021-04-26',4,2,2,65000,'','C',4,'2021-04-28 10:30:34',4,'2021-05-02 16:34:17'),(159,159,'2021-04-26',4,2,2,55000,'','C',4,'2021-04-28 10:30:58',4,'2021-05-02 16:34:59'),(160,158,'2021-04-27',4,2,2,55000,'','C',4,'2021-04-28 10:31:33',4,'2021-05-02 16:35:53'),(161,157,'2021-04-27',4,2,2,27500,'','C',4,'2021-04-28 10:32:04',4,'2021-05-02 16:31:57'),(162,157,'2021-05-01',4,2,2,52500,'','C',4,'2021-05-02 16:31:51',4,'2021-05-02 16:32:01'),(163,162,'2021-05-01',4,2,2,55000,'','C',4,'2021-05-02 16:32:45',4,'2021-05-02 16:32:56'),(164,161,'2021-05-01',4,2,2,55000,'','C',4,'2021-05-02 16:33:24',4,'2021-05-02 16:33:35'),(165,160,'2021-04-30',4,1,2,65000,'','C',4,'2021-05-02 16:34:06',4,'2021-05-02 16:34:14'),(166,159,'2021-05-01',4,2,2,55000,'','C',4,'2021-05-02 16:34:52',4,'2021-05-02 16:35:03'),(167,158,'2021-04-30',4,2,2,55000,'','C',4,'2021-05-02 16:35:41',4,'2021-05-02 16:35:49'),(168,163,'2021-05-01',4,2,2,65000,'Reserva Calu Karina Chavez','C',4,'2021-05-02 16:42:17',4,'2021-05-10 12:36:56'),(169,164,'2021-05-01',4,2,2,55000,'','C',4,'2021-05-02 16:44:59',4,'2021-05-10 12:38:02'),(170,165,'2021-05-01',4,2,4,450000,'reserva calu por mes Maria de los Angeles dos huespedes','C',4,'2021-05-02 16:48:07',4,'2021-05-10 12:36:07'),(171,166,'2021-05-08',4,1,4,120000,'','I',4,'2021-05-02 16:50:00',4,'2021-05-02 16:50:00'),(172,168,'2021-05-03',4,2,4,55000,'','C',4,'2021-05-04 08:40:53',4,'2021-05-04 08:41:00'),(173,167,'2021-05-03',4,2,2,80000,'','I',4,'2021-05-04 08:42:05',4,'2021-05-04 08:42:05'),(174,169,'2021-05-04',4,1,4,75000,'','C',4,'2021-05-05 09:06:14',4,'2021-05-05 09:06:27'),(175,170,'2021-05-04',4,2,2,55000,'','I',4,'2021-05-05 09:11:31',4,'2021-05-05 09:11:31'),(176,171,'2021-05-04',4,2,2,27500,'','I',4,'2021-05-05 09:14:41',4,'2021-05-05 09:14:41'),(177,163,'2021-05-08',4,2,2,65000,'','C',4,'2021-05-10 12:37:20',4,'2021-05-10 12:37:28'),(178,172,'2021-05-08',4,2,4,110000,'','C',4,'2021-05-10 12:40:48',4,'2021-05-10 12:40:55'),(179,173,'2021-05-08',4,2,4,110000,'','C',4,'2021-05-10 12:43:51',4,'2021-05-10 12:45:49'),(180,174,'2021-05-07',4,2,4,150000,'','C',4,'2021-05-10 12:46:25',4,'2021-05-10 12:46:35'),(181,175,'2021-05-10',4,2,4,135000,'','C',4,'2021-05-10 12:48:12',4,'2021-05-10 12:48:30'),(182,176,'2021-09-15',4,2,2,50000,'','C',4,'2021-09-07 10:15:08',4,'2021-09-07 10:15:19'),(183,177,'2021-09-07',4,3,2,0,'cortesia','I',3,'2021-09-07 10:48:56',3,'2021-09-07 10:48:56'),(184,183,'2021-10-01',4,2,4,110000,'','C',4,'2021-10-02 20:14:22',4,'2021-10-02 20:14:33'),(185,182,'2021-10-01',4,2,4,115000,'','C',4,'2021-10-02 20:15:09',4,'2021-10-02 20:15:15'),(186,181,'2021-10-01',4,2,4,115000,'','C',4,'2021-10-02 20:15:45',4,'2021-10-02 20:15:54'),(187,180,'2021-10-01',4,2,4,110000,'','C',4,'2021-10-02 20:16:27',4,'2021-10-02 20:16:34'),(188,184,'2021-10-01',4,2,4,105000,'','C',4,'2021-10-02 20:19:04',4,'2021-10-02 20:19:56'),(189,186,'2021-10-01',4,2,4,110000,'','C',4,'2021-10-02 20:19:32',4,'2021-10-02 20:19:40'),(190,185,'2021-10-01',4,2,4,110000,'','C',4,'2021-10-02 20:20:48',4,'2021-10-02 20:20:56'),(191,187,'2021-10-01',4,2,4,130000,'','C',4,'2021-10-02 20:22:01',4,'2021-10-02 20:22:17'),(192,198,'2021-10-03',4,2,4,22000,'','C',4,'2021-10-03 22:41:08',4,'2021-10-04 21:43:20'),(193,200,'2021-10-03',4,2,4,44000,'','C',4,'2021-10-04 21:45:33',4,'2021-10-04 21:45:39'),(194,201,'2021-10-03',4,2,2,22000,'','C',4,'2021-10-04 21:47:13',4,'2021-10-04 21:47:39'),(195,201,'2021-10-03',4,1,2,44000,'','C',4,'2021-10-04 21:47:33',4,'2021-10-04 21:47:42'),(196,204,'2021-10-04',4,1,4,77000,'','C',4,'2021-10-05 21:15:31',4,'2021-10-05 21:15:37'),(197,203,'2021-10-05',4,2,4,75000,'','C',4,'2021-10-05 21:16:33',4,'2021-10-05 21:16:40');
/*!40000 ALTER TABLE `tbl_con_ingresos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_mae_clientes`
--

DROP TABLE IF EXISTS `tbl_mae_clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mae_clientes` (
  `cliente_Id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_Tipo` enum('P','E') NOT NULL,
  `nacionalidad_Id` int(11) NOT NULL,
  `cliente_Rut` varchar(9) DEFAULT NULL,
  `cliente_Nombres` varchar(100) NOT NULL,
  `cliente_ApellidoPaterno` varchar(100) NOT NULL,
  `cliente_ApellidoMaterno` varchar(15) DEFAULT NULL,
  `pais_Id` int(11) DEFAULT NULL,
  `region_Id` int(11) DEFAULT NULL,
  `ciudad_Id` int(11) DEFAULT NULL,
  `comuna_Id` int(11) DEFAULT NULL,
  `cliente_Direccion` varchar(100) DEFAULT NULL,
  `cliente_CorreoElectronico` varchar(50) NOT NULL,
  `cliente_TelefonoFijo` varchar(15) DEFAULT NULL,
  `cliente_Celular` varchar(15) NOT NULL,
  `cliente_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`cliente_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mae_clientes`
--

LOCK TABLES `tbl_mae_clientes` WRITE;
/*!40000 ALTER TABLE `tbl_mae_clientes` DISABLE KEYS */;
INSERT INTO `tbl_mae_clientes` (`cliente_Id`, `cliente_Tipo`, `nacionalidad_Id`, `cliente_Rut`, `cliente_Nombres`, `cliente_ApellidoPaterno`, `cliente_ApellidoMaterno`, `pais_Id`, `region_Id`, `ciudad_Id`, `comuna_Id`, `cliente_Direccion`, `cliente_CorreoElectronico`, `cliente_TelefonoFijo`, `cliente_Celular`, `cliente_Estado`) VALUES (5,'P',11,'136750569','Victor','Lara','',11,NULL,NULL,NULL,'Vivar 1153, of 602','vlarap@centraltecnologica.cl','','994981050','A'),(6,'',38,'18.373.41','Bayron andres','Fernández','Torres',38,1,3,1,'Los algarrobos 3751','bayronandres.fernandez@hotmail.com','','949558257','A'),(7,'E',38,'764940873','sunor ltda',' Obras de ing ','',38,1,3,1,'','cbarnao@sunor.cl',' Calle Nueva UN','956589321','A'),(8,'E',38,'764940873','SUNOR LTDA',' Obras ING','',38,1,3,1,' Calle Nueva Uno 4921','cbarnao@sunor.cl','','956589321','A'),(9,'',38,'229257943','Javiera ','Bradnock','',NULL,NULL,NULL,NULL,'','jbradnock@hotmail.com','','984236541','D'),(10,'E',38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555','A'),(11,'P',38,'132167060','Luis Alejandro','Sierra','Quispe ',38,2,NULL,NULL,'','luissierra282@gmail.com','','994156041','A'),(12,'P',38,'159109135','Cristian Andres',' Ojeda ','Ojeda',38,2,NULL,NULL,'','cristian_calama@hotmail.com','','994156041','A'),(13,'P',38,'19436322-','Gabriela Paz','Figueroa','Osorio',38,1,3,NULL,' Edificio Playa Huantajaya 2030','nicoleot@gmail.com','','961084085','A'),(14,'P',38,'18503607-','Rosrigo Esteban ','Vergara','Viza',38,1,3,2,'Cale 1 numero 4610 la tortuga Alto Hospicio','rvergraviza21@gmail.com','','990506043','A'),(15,'P',38,'17852649-','Danitza ','Barrios ','Farias',38,1,3,1,'Recabarren 2779','danitzabafa@gmail.com','','982616871','A'),(16,'P',38,'18262561-','Diego Maximiliano','Burgos ','Lquiz',38,1,3,1,'Los Chunchos 3982','diego23177@hotmail.com','','944073887','A'),(17,'',38,'13009097-','Fernando reinaldo','Gutierrez','Cortes',38,1,3,1,'Las Cacharpayas 2331','fernandogutierrezcortes@gmail.com','','991607985','A'),(18,'',38,'16.624.68','Ana estefania ','Ulloa ','Ulloa ',38,1,3,1,'Avenida salvador allende 448 ','anitaestefaniaulloa@gmail.com','','982853471 ','A'),(19,'',38,'15609451k','Claudia alejandra','Zurita','Acevedo',38,1,3,2,'Avenida Gladis Marín ','claudiax450129@gmail.com','','958977399','A'),(20,'',38,'191798147','Javiera ','Valenzuela','Cuellar',38,1,3,2,'Ac parque 2 3243','javieravc1504@gmail.com','','982020660','A'),(21,'',38,'17431148k','Paulina ','Taboada','Tobar ',38,15,1,343,'Santiago Arata Gandolfo #4305 ','pau.taboada22@gmail.com','','962283444','A'),(22,'',38,'17431148-','Paulina Isabel','Taboada ',' Tobar',38,15,1,343,'Santiago Arata Gandolfo #4305','pau.taboada22@gmail.com','','962283444','A'),(23,'',38,'117533743','Rodrigo','Vergara','Allendes',38,1,3,1,'Los chunchos 3668','socomin2013@gmail.com','940734109','940734109','A'),(24,'P',38,'176568739','Leandro Antonio',' Olivares ','Opazo',38,1,3,1,'La Puntilla 579 depto 303','Leandro.olivares1792@gmail.com','','979774204','A'),(25,'P',38,'00000000','Roxana ','Cerda','',38,1,3,1,'','roxana.cerda@gmail.com','','962494294','A'),(27,'P',38,'189001762','Giresse Alejandra','Aguirre','Leiva',38,1,3,1,' Tamarugal 2993 depto 195','giresseaaguirre@gmail.com','','988275217','A'),(28,'P',38,'117533743','Rodrigo','Vergara','Allendes',38,1,3,1,'','socomin2013@gmail.com','','940734109','A'),(30,'P',38,'12608066-','David Samuel','Bugueño','Mamani',38,15,1,343,'','david.b.33@hotmail.com','','988334428','A'),(31,'P',38,'16592293k','Giselle ','Salinas ','Morales',38,1,3,2,'El Alto 2271 Block 13 depto 402','giselle.salinas.m@gmail.com','','967767482','A'),(32,'P',38,'12763136-','Rodolfo','Muñoz','Gonzalez',38,1,3,1,' Grumete Bolado 63','rmunoz@gmail.es','','979129996','A'),(33,'P',38,'119049741','Paola ','Rubio ','Ruiz',38,1,3,1,'Grumete Bolados 63 block 3 depto 44','paolarubioestilista@gmail.com','','993735595','A'),(34,'P',38,'165929047','Crystal ','Figueroa','',38,1,3,1,'el tamarugal 2993','figueroacrystal2@gmail.com','','956899644','A'),(35,'P',38,'16056820-','Jose Luis','Contreras ','Mamani',38,1,3,2,' Av detective jose cubillos 3430 block 8 depto 2020','joseluiscontreras.trabajo@gmail.com','','942790951','A'),(36,'P',38,'17874110-','Fernanda Valentina ','Escobar ',' Puentes',38,1,3,2,' Valle del sol 3342 block11 depto 202','fernandaepuentes@gmail.com','','984378696','A'),(37,'P',38,'18897962-','Alvaro','Paschuan','',38,1,3,1,' Heroes de la concepcion 2775','a.paschuan.h@outlook.com','','995954089','A'),(38,'P',38,'14296561-','Cristian ','Olivares','Pasten',38,1,3,1,'esmeralda 528 depto 81','crop@gmail.com','','95947722','A'),(39,'P',38,'10644073-','Rosa','Godoy',' Saez',38,15,1,343,'Olivarera de azapa 2377','cabanas.kiwiland@gmail.com','','971907016','A'),(40,'P',38,'13640231-','Andrea ','gODOY ','Saez',38,15,1,343,'Orozimbo Barboza 2654','cabanas.kiwiland@gmail.com','','971907016','A'),(41,'P',38,'12612077-','Javier','Quevedo',' Gonzalez',38,15,1,343,'Sant Ines 4270','cabanas.kiwiland@gmail.com','','979993995','A'),(42,'P',38,'170925580','Carlos ','Aguilera ','Figueroa',38,2,7,15,'','cabanas.kiwiland@gmail.com','','981403571','A'),(43,'P',38,'19734128-','Ada','Araya ','Carvajal',38,1,4,3,' Hector Basualto 1031 villa milenium','cabanas.kiwiland@gmail.com','','942958213','A'),(44,'P',38,'17555457-','Kihara ','San Francisco','',38,15,1,343,' Libertad 2273','kiharasanfrancisco@gmail.com','','965527661','A'),(45,'P',38,'17388662-','Anita','Jorquera ','Aguilera',38,1,4,3,' Libertad 891','maria.aguilera.jorquera@gmail.com','','940435931','A'),(46,'P',38,'16349316-','Natalia ','Cortes ','Mñoz ',38,1,4,3,' Negreiros 664 Villa Santa Ana','ncortesmu@gmail.com','','950990140','A'),(47,'P',38,'10214470-',' Patricia ','Muñoz','Olivares',38,1,4,3,' Negreiros 664 Villa Santa Ana','ncortesmu@gmail.com','','950990140','A'),(48,'P',38,'16349316-',' Natalia','Cortes','Muñoz',38,1,NULL,NULL,'negreiros 664 villa santa ana','ncortesmu@gmail.com','','950990140','A'),(49,'P',38,'11719736-','Juan ','Pizarro','Gomez',38,2,7,15,' Chorrillos 1518','juantoco@hotmail.com','','940334655','A'),(50,'P',38,'121731355','Ruben','Concha ','Cabrera',38,15,1,343,'cienfuegos 1462','rubencabreraconcha@gmail.com','','975254881','A'),(51,'P',38,'136750569','Víctor','Lara','Parra',38,1,3,1,'Nicolas Urrutia 1960-B','vlarap@centraltecnologica.cl','994981050','994981050','A'),(53,'P',38,'12609676-','Cristian ','Cortes','',38,15,1,343,' Jose Morales 4319','corrtee.oo@gmail.com','','948467988','A'),(54,'P',38,'6883611-5','Guillermo','Gallardo','Ponce',38,15,1,343,'Renaico 2342','gallardo.ponce56@gmail.com','','976962199','A'),(56,'P',38,'14223066-','Ruben','Carvajal',' Salazar',38,1,4,3,' Juan Martinez 215 Villa Militar Baquedano','eventosgastronomicos13@gmail.com','','988670875','A'),(58,'P',38,'182653276','Javier','Guzman','',38,15,1,343,'Macul 2521','javier.uta@gmail.com','','987468583','A'),(60,'P',38,'12426295-','Mauricio ','Veas','',38,2,5,8,'anacleto solorza 9780','mauroveasp@gmail.com','','940106989','A'),(61,'P',38,'18035852-','Tiare D','Diaz  ','Tapia',38,1,4,3,' San Fuente 12','tiare.diaz.tapia@gmail.com','','954850474','A'),(62,'P',38,'11621410-','Guido','Tapia','Quitral',38,1,4,3,' San Fuente 11','gtapiaquitral@gmail.com','','976271463','A'),(63,'P',38,'19152571-','Barbara ','Castillo ','Tapia',38,1,4,3,' San Espedito 5 Fundo Santa Emilia  Sur','castillotapiabarbara@gmail.com','','931146539','A'),(64,'P',38,'12937934-','Juan','Figueroa ','Ramirez',38,2,7,15,' Combate de la concepcion 596','j_f_r_76@hotmail.com','','977620336','A'),(65,'P',38,'12347348-','Marco ','Aguirre','Gomez',38,2,7,15,'Teniente Merino 09','fitodomi1973@gmail.com','','977620336','A'),(66,'P',38,'15070022-','Hector','Cuevas ','Reyes',38,15,1,343,' Agustin Caballero 2550','hectorcuevasreyes@gmail.com','','951974515','A'),(67,'P',38,'14237845-','Marco','Rivera','Romero',38,2,7,15,' Pasaje Calama 2757 Villa Los Andea','electrmar@hotmail.com','','950398550','A'),(68,'P',38,'13005290-','Pablo','Cortes','',38,15,1,343,'San Ignacio Loyola 850 block D depto 203','corrtee.99@gmail.com','','948467988','A'),(69,'P',38,'18898969-','Nadine ','Vargas ','Mejias',38,1,4,7,'Los Mangos 64','nvargasmejias@gmail.com','','987025073','A'),(70,'P',38,'16253744-',' Francisca ','Donoso',' Gonzalez',38,1,3,1,' Padre  Hurtado2369 Torre Norte DEPTO 1702','donosogonzalez.fran@gmail.com','','956471502','A'),(71,'P',38,'14103792-','Rodrigo ','Espinola ','Fuentes',38,1,4,3,'mamiña 743','r_espinola@live.cl','','956936222','A'),(72,'P',38,'16772453-','Yoceling','Alfaro','Arias',38,15,1,343,' colina 1918','yoceling.alfaro@gmail.com','','952145670','A'),(73,'P',38,'17094166-','Tatiano ','Pizarro ','Morales',38,2,7,15,' Avenida Nuva oriente 2878','tatiana.pizarro@gmail.com','','966892262','A'),(74,'P',38,'15692851-','Teresa','Caceres','Macpherson',38,15,1,343,'Oozimbo barboza3722','prof.teresacaceres@hotmail.com','','944301134','A'),(75,'P',38,'13008936-','Jaime Alex','Oropessa ','Pereira',38,1,3,2,' Puerto Varas 4529','alexoropessa@gmail.com','','965059893','A'),(78,'P',38,'18829938-',' Ruben ','Gacitua ',' Gonzalez',38,13,49,279,'San Rosendo 1388 block E  depto 23','ruben.agacitua@gmail.com','','984266368','A'),(79,'E',38,'76924391-',' Productora  Perro Andante E.I.R.L','Teatro ','',38,1,3,NULL,' Los moreños 2877 ','teatroperroandante@gmail.com','','958400322','A'),(81,'E',38,'76924392-','Productora perro andante E.I.R.L','actividades de produccion','',38,1,3,1,' Los moreños 2877 ','teatroperroandante@gmail.com','','958400322','A'),(82,'E',38,'76924391-','Productora perro andante E.I.R.L','actividades de produccion','',38,1,3,1,'Los moreños 2877','teatroperroandante@gmail.com','','958400322','A'),(83,'E',38,'76924391-','Productora perro andante E.I.R.L','actividades de produccion','',38,1,3,1,'Los moreños 2877','teatroperroandante@gmail.com','','958400322','A'),(84,'E',38,'76924391-','Productora perro andante E.I.R.L','actividades de produccion','',38,1,3,1,'Los moreños 2877','teatroperroandante@gmail.com','','958400322','A'),(85,'P',38,'159758648','Nathalie ','Huerta','',38,2,7,15,' 18 de mayo 766 villa chuquicamata','nhuerta175@gmail.com','','945527592','A'),(86,'P',38,'15180015-','Marcela','Nuñez','Sanhueza',38,2,7,15,' Calle Juan Daniel Ruiz 100','marcelanunezsanhueza@gmail.com','','963757504','A'),(87,'P',38,'135387040','Jose Mauricio','Tapia ','Diaz',38,2,7,15,'Huaman 613','josetapiadiaz11@gmail.com','','942487733','A'),(88,'P',38,'180170804','Jacqueline ','Sanchez','Esteban',38,1,4,3,' Arica 670','jaque.saanchez@gmail.com','','958616188','A'),(89,'P',38,'17937556-','Katherine','Matinez','Vega',38,2,5,8,'av huamachuco 8833','k.martinez.vega91@gmail.com','','977697995','A'),(90,'P',38,'17430958-','Camilo','Soto Cuevas','',38,1,3,2,'Av Las Parcelas 4010','camiloenriquesoto@gmail.com','','942396814','A'),(91,'P',38,'159722910','Carla ','Marin ','Herrera',38,1,3,1,'Dos Oriente 4649','carla.marin.herrera@gmail.com','','994965912','A'),(92,'P',38,'165918991','Claudia ','Poblete','Borquez',38,1,3,1,' AV arturo pratt 1670','claudiapoblete@live.com','','965910329','A'),(93,'P',38,'10228632-','Adolfo ','Guerra','Sepulveda',38,1,3,2,' Villa Frey3 3302','adolfoturoguerra@gmail.com','','937068878','A'),(94,'P',38,'17131763','Consuelo','Guerra ','Sepulveda',38,1,3,2,'Villa Frey calle 3 3298','insudentgyg@gmail.com','','937068878','A'),(95,'P',38,'q6866466-','Milenka ','Aguirre','',38,1,3,2,'','milenka.next.21@gmail.com','','978705499','A'),(97,'P',38,'185062805','Salomea','Estay','',38,1,3,1,'calcopirita 4239','salome.estay@gmail.com','','998206647','A'),(98,'P',38,'159503275','Marcia ','Flores','Filgueira',38,1,3,1,' Violeta Parra 4008','flores.filgueira@gmail.com','','986962116','A'),(99,'P',38,'163503654','Valeria jesus','Olivero','Herrera',38,1,3,1,'General Ibañez','voliveroh@gmail.com','','956486091','A'),(100,'P',38,'187443598','Natalia ','Miranda','Soto',38,1,3,2,' Calle 2 3717 La tortuga','nataliamiranda164@gmail.com','','967480403','A'),(101,'P',38,'178400584','Barbara','Peña','',38,1,3,1,' Via Local 2 4057depto 13','pcarrionbarbara@gmail.com','','942637933','A'),(102,'P',38,'159503275','Marcia','flores','Filgueira',38,1,3,2,'Violeta Parra 4008','flores.filgueira@gmail.com','','986962116','A'),(103,'P',38,'14599577','Sergio ','Vidal','',38,1,3,1,'av francisco bilbao 3421','sergiovidalbasai@gmail.com','','999927110','A'),(104,'P',38,'160568208',' Jose Luis ','Contreras ','Mamani',38,1,3,2,'av detective jose cubillos 3430 block 8 depto 202','joseluiscontreras.trabajo@gmail.com','','955268106','A'),(105,'P',38,'169087954',' Robert Cristian',' Riquelme','',38,1,3,1,' Condominio Altos de Huayquique  av la tirana  4865 depto 66','robert.riquelme.g@gmail.com','','945397467','A'),(106,'P',38,'178008730','Nicole','Ceballos','',38,1,3,1,' Libertal 1922','nicolceballosu@gmail.com','','988245503','A'),(107,'P',38,'174616428','Sergio','Sanzana','',38,1,3,2,'cerro esmeralda 2836','ssanzanag@investigaciones.cl','','965706341','A'),(108,'P',38,'135082023','Marcela ','Garcia','',38,1,3,1,'Salvador Allende 855','garciaov12@gmail.com','','993085892','A'),(109,'P',38,'168647190','Nadia ','Aguilera ','Mondac',38,1,3,1,'av arturo prat block 699 depto 12','nadia.aguileramondaca@gmail.com','','996804139','A'),(110,'P',38,'182634964','Macarena ','Castillo ','Cortes',38,1,3,1,'Moises Gonzales 1601','castillocm19@gmail.com','','999309213','A'),(111,'P',38,'75777884',' syliva ','Rosas',' Urra',38,1,3,1,'grumete bolados 168 ','pivyta@gmail.com','','956983397','A'),(112,'P',38,'188979629','Alvaro','Paschuan','',38,1,3,1,'','a.paschuan.h@outlook.com','','995954089','A'),(113,'P',38,'19042412k','Joyce ','Muñoz','',38,1,3,1,'pasaje siete 3657','joyce.constanza@gmail.com','','965395317','A'),(114,'P',38,'16704798','Nathaly','Pizarro','Ordoñez',38,1,3,2,'rio maipo 3036','nathalypizarro26@gmail.com','','961761493','A'),(115,'P',38,'182648744','Juan Pablo','Pizarro','Ordoñez',38,1,3,2,'av gabriela mistral 3924','nathalypizarro26@gmail.com','','961761493','A'),(116,'P',38,'122161315','Patricio','Araya','',38,2,5,8,' sendero del sol 456 casa 41','pato.araya1521@gmail.com','','954237058','A'),(117,'P',38,'132149666','Gissel ','GOody','Riquelme',38,1,3,1,'5 sur 4272 depto 2304A','arq_ggodoy@yahoo.com','','977641575','A'),(118,'P',38,'145672651','Carola ','Astudillo ','Herrera',38,1,3,1,'Los Chunchos 346','contacto@kiwiland.cl','','951490403','A'),(119,'P',38,'116199645','Ubaldo Elias','Ferruzola ','Porra',38,1,3,2,' Los nogales 2931 ','ubaldo1968@hotmail.com','','996585637','A'),(120,'P',38,'199105655','Alein Ignacio','Osorio','Varas',38,1,3,2,' Av las parcelas pasaje san antonio 3514','aleinosorio98@gmail.com','','963227728','A'),(121,'P',38,'105725558','Claudio ','Bahamondes','',38,1,3,1,' avenida costanera 3524 casa 48','bahamondes_claudio@hotmail.com','','979699822','A'),(122,'P',38,'160562641','Samanta','Cortes','Ramirez',38,1,3,1,'Pasaje Ruben Donoso 2982 depto 10','samanta.c.r@gmailcom','','999090757','A'),(123,'P',38,'15010826-','Lorena ','Challapa','Moscoso',38,1,3,2,' Los almendros 2885','contacto@kiwiland.cl','','931732667','A'),(126,'P',38,'15689847k','Alejandrs','Castillo','Contreras',38,2,5,8,' libertad 3033','alejandracastillo2411@gmail.com','','950919690','A'),(127,'P',38,'16437338k','Jonatan Andres ','Alvarez','Espinoza',38,2,5,8,'curico 2650','jonatan.alvarez.alon@gmail.com','','964481311','A'),(128,'P',38,'156422657','Gisselle','Chaparro','Rivera',38,1,3,1,'salvador allende 555 torre A depto 154 condominio portada oriente','ikelmito@gmail.com','','967387626','A'),(129,'P',38,'12213313-','Cristian ','Elizalde','',38,1,3,1,'Los Alelies 1869','elizaldecristian72@hotmail.com','','921971197','A'),(130,'P',38,'147422970','Rudy','Quevedo','',38,1,3,1,'','kizzy.rojas@hotmail.co','','948841569','A'),(132,'P',38,'209628163','Isabel','Imbarack','',38,15,1,343,'jose joaquin 837','isaimbarack@hotmail.com','','964175514','A'),(133,'P',38,'174319677','Yesenia ','Borquez ','Sandoval',38,1,3,2,' Avenida iquique 35','ronnysilva69@gmail.com','','975712208','A'),(134,'P',38,'19179189-','Brandon ','Mamani','',38,1,4,3,'Sillajuay 520','brandonbreimom.m@gmail.com','','958481967','A'),(135,'P',38,'188827888','Juan Carlos','Vasquez','',38,1,3,1,'Pasaje Sibaya 2272','juancarvato2015@gmail.com',' ','988943646','A'),(136,'P',38,'16614647k','Maritza ','Mamani','Garcia',38,1,3,2,' los condores 1957','susanamamani25@gmail.com','','945886362','A'),(137,'P',38,'0000000-9','Rosana ','Pizarro','',38,1,3,1,'','contacto@kiwiland.cl','','974603780','A'),(138,'P',38,'177999180','Luis Alberto','Linares','Catalan',38,1,4,3,'calle 2 numero 274 ','luis23linaresc@gmail.com','','937822342','A'),(139,'P',38,'24208084-','Karimdad','Jalandari','',38,1,3,1,' capitan roberto perez 2777','norhpacif878@gmail.com','','984029394','A'),(140,'P',38,'161351172','Paz','Gonzalez','',38,1,3,2,'Michielle Bachelet 3750','violeta.24mp@gmail.com','','968700894','A'),(141,'P',38,'137935775','LUIS','Oyarce','',38,1,3,1,'Obispo Labbe 370','loyarce.avila@gmail.com','','950114094','A'),(142,'P',38,'182627720','Daniela','Rodriguez','',38,1,4,6,' Santa Rosa 4220','danii.rodriguez@icloud.com','','963910257','A'),(143,'P',38,'105024916','Alejandro ','Vera','',38,1,3,1,' av diagonal sur 4245','avjofre@hotmail.com','','983620209','A'),(145,'P',38,'17431300-','Valeria','Nievas','',38,1,3,1,'','nievas1990@gmail.com','','971811335','A'),(146,'P',38,'17726149-','Alexis','Ramos','',38,2,5,9,'fertilizantes702','alexis.ramos.91@outlook.com','','985021584','A'),(147,'P',38,'178012363','Francisca','Suarez','Ruiz',38,1,3,2,'pasaje rio valdivia 3025','francisca.suarezruiz@gmail.com','','998006009','A'),(148,'P',38,'165508602','brian','Espinoza','',38,1,3,1,'tadeo haenke 2526','contacto@kiwiland.cl','','953946395','A'),(149,'P',38,'188966926','Nycol','Muñoz','',38,1,3,1,'','nycol.mr@gmail.com','','986867575','A'),(150,'P',38,'180040161',' Juan Carlos','Amaya','',38,1,3,1,'','jcamaya23@gmail.com','','956694957','A'),(151,'P',38,'199786903','Barbara','Challapa','',38,1,3,1,'coquimbo 2264','b.andreachallapa@outlook.com','','937592881','A'),(152,'P',38,'155248092','Daniela ','Soto','',38,1,3,1,'','danielasoto26@gmail.com','','971651031','A'),(153,'P',38,'159023958','Grace','Sotomayor',' Merino',38,1,3,1,'Francisco Bilbao 4148depto 2102','g.sotomayor@gmail.com','','976457858','A'),(154,'P',38,'17017258-','Daniza ','Callejas','Olivares',38,1,3,1,'Padre Hurtado 2389 depto 1703','danizaelizabeth@gmail.com','','947714442','A'),(155,'P',38,'17017258-','Daniza ','Callejas','Olivares',38,1,3,1,'Padre Hurtado 2389 depto 1703','danizaelizabeth@gmail.com','','947714442','A'),(156,'P',38,'170172582','Daniza ','Callejas','Olivares',38,1,3,1,'Padre Hurtado 2389 depto 1703','danizaelizabeth@gmail.com','','947714442','A'),(157,'P',38,'161502200','Francisca','Saavedra','Lopez',38,1,3,1,'Chipana 2040','saavedra_francisca@hotmail.com','','966179258','A'),(158,'P',38,'161502200','Francisca','Saavedra','Lopez',38,1,3,1,'Chipana 2040','saavedra_francisca@hotmail.com','','966179258','A'),(159,'P',38,'161502200','Francisca','Saavedra','Lopez',38,1,3,1,'Chipana 2040','saavedra_francisca@hotmail.com','','966179258','A'),(160,'P',38,'146056989','Joscelyne ','Parra','Santos',38,1,3,2,'','joscelyneparra@gmail.com','','989229219','A'),(161,'P',38,'118308441','Richard','Delgado ','Hidalgo',38,1,3,1,'2 oriente 4833','richardd012011@gmail.com','','944699963','A'),(162,'P',38,'156802964','Evelyn ','Caimanque','Martinez',38,1,3,2,'Hospicio Rio Bio Bio 3025','eve515caimanque@gmail.com','','987415851','A'),(163,'P',38,'156802964','Evelyn ','Caimanque','Martinez',38,1,3,2,'Alto Hospicio Rio Bio Bio','eve515caimanque@gmail.com','','987415851','A'),(164,'P',38,'147422970','Rudy Andrian','Quevedo','Hayan',38,1,3,1,'','quevedohuayan@gmail.com','','948841569','A'),(165,'P',38,'22906214K','Yelitza','Huayan','Guzman',38,1,3,1,'','quevedohuayan@gmail.com','','948841569','A'),(166,'P',38,'132440379','Erika','Silva','Cuzmar',38,4,11,26,'Veneto 404','erisicu@hotmail.com','','957882699','A'),(168,'P',38,'126973500','Luis','Rojas','Gutierrez',38,1,3,1,'Condominio La Tirana calle D casa 102','luisrojasgutierrez@gmail.com','','959258736','A'),(170,'P',38,'52525772','Alejandro','Acuña','Paez',38,2,7,15,'cienfuegos 1601','acunapaez@gmail.com','','998660269','A'),(171,'P',38,'199762613','domenika','larco','toledo',38,1,3,1,'pasaje tres islas 3617','domenikalarcotoledo@outlook.cl','','985053263','A'),(172,'P',38,'16436111-','Felipe ','Tudela','',38,2,5,8,'Pisana 690','felipe.t.tudela@gmail.com','','957206811','A'),(173,'P',38,'158127342','Carolina','Arriagada','Maluenda',38,2,5,8,'Santiago Humberstone 125','carolinaarriagadamaluenda@gmail.com','','993808433','A'),(174,'P',38,'124193915','Ximena ','Ahumada','',38,2,5,8,'','ximeaaa@gmail.com','','932225657','A');
/*!40000 ALTER TABLE `tbl_mae_clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_mae_clientevaloraciones`
--

DROP TABLE IF EXISTS `tbl_mae_clientevaloraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mae_clientevaloraciones` (
  `valoracion_Id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_Id` int(11) NOT NULL,
  `reserva_Id` int(11) NOT NULL,
  `valoracion_Puntaje` int(11) NOT NULL,
  `valoracion_Observacion` text NOT NULL,
  `valoracion_UsuarioCrea` int(11) NOT NULL,
  `valoracion_FechaCrea` datetime NOT NULL,
  `valoracion_UsuarioModifica` int(11) DEFAULT NULL,
  `valoracion_FechaModifica` datetime DEFAULT NULL,
  PRIMARY KEY (`valoracion_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mae_clientevaloraciones`
--

LOCK TABLES `tbl_mae_clientevaloraciones` WRITE;
/*!40000 ALTER TABLE `tbl_mae_clientevaloraciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_mae_clientevaloraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_mae_funcionarios`
--

DROP TABLE IF EXISTS `tbl_mae_funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mae_funcionarios` (
  `funcionario_Id` int(11) NOT NULL AUTO_INCREMENT,
  `funcionario_Rut` varchar(9) NOT NULL,
  `cargoFuncionario_Id` int(11) NOT NULL,
  `funcionario_Nombres` varchar(45) NOT NULL,
  `funcionario_ApellidoPaterno` varchar(20) NOT NULL,
  `funcionario_ApellidoMaterno` varchar(20) DEFAULT NULL,
  `funcionario_Direccion` varchar(60) DEFAULT NULL,
  `funcionario_Telefono` varchar(15) DEFAULT NULL,
  `funcionario_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`funcionario_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mae_funcionarios`
--

LOCK TABLES `tbl_mae_funcionarios` WRITE;
/*!40000 ALTER TABLE `tbl_mae_funcionarios` DISABLE KEYS */;
INSERT INTO `tbl_mae_funcionarios` (`funcionario_Id`, `funcionario_Rut`, `cargoFuncionario_Id`, `funcionario_Nombres`, `funcionario_ApellidoPaterno`, `funcionario_ApellidoMaterno`, `funcionario_Direccion`, `funcionario_Telefono`, `funcionario_Estado`) VALUES (5,'177518689',4,'Mahicol Alejandro','Castillo','Valenzuela','Vivar 123','930212661','A'),(6,'136750569',4,'Victor','Lara','','Vivar 1153, of 602','994981050','A'),(7,'229257943',5,'Javiera','Bradnock','','','','A'),(8,'999999999',5,'prueba','prueba','','','','A');
/*!40000 ALTER TABLE `tbl_mae_funcionarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_mae_imagenespropiedad`
--

DROP TABLE IF EXISTS `tbl_mae_imagenespropiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mae_imagenespropiedad` (
  `imagen_Id` int(11) NOT NULL AUTO_INCREMENT,
  `propiedad_Id` int(11) NOT NULL,
  `propiedad_Imagen` varchar(45) NOT NULL,
  PRIMARY KEY (`imagen_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mae_imagenespropiedad`
--

LOCK TABLES `tbl_mae_imagenespropiedad` WRITE;
/*!40000 ALTER TABLE `tbl_mae_imagenespropiedad` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_mae_imagenespropiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_mae_propiedades`
--

DROP TABLE IF EXISTS `tbl_mae_propiedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mae_propiedades` (
  `propiedad_Id` int(11) NOT NULL AUTO_INCREMENT,
  `propiedad_Nombre` varchar(45) NOT NULL,
  `propiedad_Capacidad` int(11) NOT NULL,
  `propiedad_Descripcion` text NOT NULL,
  `propiedad_Mantencion` enum('A','D') NOT NULL DEFAULT 'D',
  `propiedad_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`propiedad_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mae_propiedades`
--

LOCK TABLES `tbl_mae_propiedades` WRITE;
/*!40000 ALTER TABLE `tbl_mae_propiedades` DISABLE KEYS */;
INSERT INTO `tbl_mae_propiedades` (`propiedad_Id`, `propiedad_Nombre`, `propiedad_Capacidad`, `propiedad_Descripcion`, `propiedad_Mantencion`, `propiedad_Estado`) VALUES (1,'Cabaña 2',7,'Cocina americana, una habitación con dos camarotes, una habitación con una cama matrimonial, un baño y un camarote en el living. En el exterior:  Cuenta con su propio quincho, amplia terraza con comedor y dos estacionamientos.-','A','A'),(2,'Cabaña 3',8,'Cocina americana, una habitación con dos camarotes, una habitación con una cama matrimonial en un solo ambiente, un baño y una cama nido en el living. En el exterior:  Cuenta con su propio quincho, amplia terraza con comedor y dos estacionamientos.','A','A'),(3,'Cabaña 4',8,'Cocina americana, una habitación con dos camarotes, una habitación con una cama matrimonial, un baño y un camarote en el living. En el exterior:  Cuenta con su propio quincho, amplia terraza con comedor y un estacionamiento.','A','A'),(4,'Cabaña 5',8,'Cocina americana, una habitación con dos camarotes, una habitación con una cama matrimonial, un baño y un camarote en el living. En el exterior:  Cuenta con su propio quincho, amplia terraza con comedor y un estacionamiento.','A','A'),(5,'Cabaña 6',8,'Cocina americana, una habitación con dos camarotes, una habitación con una cama matrimonial en un solo ambiente, un baño y una cama nido en el living. En el exterior:  Cuenta con su propio quincho, amplia terraza con comedor y dos estacionamientos.','A','A'),(6,'Cabaña 7',9,'Cocina americana, una habitación con un camarote y una cama de dos plazas, una habitación con una cama de dos plazas y una cama de plaza, un baño y una cama nido en el living. En el exterior:  Cuenta con su propio quincho, amplia terraza con comedor y dos estacionamientos.','A','A'),(7,'Cabaña 8',8,'Cocina americana, una habitación con dos comarotes, una habitación con una cama de dos plazas, un baño y una cama nido en el living. En el exterior:  Cuenta con su propio quincho, amplia terraza con comedor y dos estacionamientos.','A','A'),(8,'Cabaña 1',7,'datos de cabaña','A','A'),(9,'Quincho 1',15,'Amplio Quincho, con comedor, electricidad y lavaplatos ','A','A'),(10,'Quincho 2',5,'Espacio por el día que da derecho a uso de espacios comunes, comedor, quincho y piscina','A','A'),(11,'Quincho 3',7,'Espacio  por el día,  da derecho a uso de piscina, espacios comunes, quincho, comedor y otros.','A','A');
/*!40000 ALTER TABLE `tbl_mae_propiedades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_mae_serviciospropiedad`
--

DROP TABLE IF EXISTS `tbl_mae_serviciospropiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mae_serviciospropiedad` (
  `servicio_Id` int(11) NOT NULL,
  `propiedad_Id` int(11) NOT NULL,
  PRIMARY KEY (`servicio_Id`,`propiedad_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mae_serviciospropiedad`
--

LOCK TABLES `tbl_mae_serviciospropiedad` WRITE;
/*!40000 ALTER TABLE `tbl_mae_serviciospropiedad` DISABLE KEYS */;
INSERT INTO `tbl_mae_serviciospropiedad` (`servicio_Id`, `propiedad_Id`) VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),(3,1),(3,2),(3,3),(3,4),(3,5),(3,6),(3,7);
/*!40000 ALTER TABLE `tbl_mae_serviciospropiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_cargosfuncionario`
--

DROP TABLE IF EXISTS `tbl_man_cargosfuncionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_cargosfuncionario` (
  `cargoFuncionario_Id` int(11) NOT NULL AUTO_INCREMENT,
  `cargoFuncionario_Nombre` varchar(30) NOT NULL,
  `cargoFuncionario_DeSistema` enum('S','N') NOT NULL DEFAULT 'N',
  `cargoFuncionario_Estado` enum('A','D') NOT NULL,
  PRIMARY KEY (`cargoFuncionario_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_cargosfuncionario`
--

LOCK TABLES `tbl_man_cargosfuncionario` WRITE;
/*!40000 ALTER TABLE `tbl_man_cargosfuncionario` DISABLE KEYS */;
INSERT INTO `tbl_man_cargosfuncionario` (`cargoFuncionario_Id`, `cargoFuncionario_Nombre`, `cargoFuncionario_DeSistema`, `cargoFuncionario_Estado`) VALUES (4,'Ingenierio de Software','S','A'),(5,'Gerente','N','A');
/*!40000 ALTER TABLE `tbl_man_cargosfuncionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_categorias`
--

DROP TABLE IF EXISTS `tbl_man_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_categorias` (
  `categoria_Id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_Sigla` varchar(5) NOT NULL,
  `categoria_Nombre` varchar(25) NOT NULL,
  `categoria_Tipo` enum('I','E','A') NOT NULL COMMENT '(I)NGRESO, (E)GRESO, (A)MBOS',
  `categoria_DeSistema` enum('S','N') NOT NULL DEFAULT 'N',
  `categoria_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`categoria_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_categorias`
--

LOCK TABLES `tbl_man_categorias` WRITE;
/*!40000 ALTER TABLE `tbl_man_categorias` DISABLE KEYS */;
INSERT INTO `tbl_man_categorias` (`categoria_Id`, `categoria_Sigla`, `categoria_Nombre`, `categoria_Tipo`, `categoria_DeSistema`, `categoria_Estado`) VALUES (1,'COM','Compras insumos aseo','E','N','A'),(2,'Abono',' Abono  de reserva','I','N','A'),(3,'LCHEC','Late check out ','I','N','A'),(4,'EST','Estadía','I','S','A'),(5,'Luz','Luz','E','N','A'),(6,'Inven',' Inventario ','I','N','A'),(7,'Recur',' Remuneraciones','E','N','A'),(9,'Recur','Imposiciones','E','N','A'),(10,'IVA',' IVA','E','N','A'),(11,'Cable','Cable','E','N','A'),(12,'Telef','Telefonos ','E','N','A'),(13,'PSJAD','Pasajero adicional','I','N','A');
/*!40000 ALTER TABLE `tbl_man_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_centroscosto`
--

DROP TABLE IF EXISTS `tbl_man_centroscosto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_centroscosto` (
  `cCosto_Id` int(11) NOT NULL AUTO_INCREMENT,
  `cCosto_Nombre` varchar(45) NOT NULL,
  `cCosto_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`cCosto_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_centroscosto`
--

LOCK TABLES `tbl_man_centroscosto` WRITE;
/*!40000 ALTER TABLE `tbl_man_centroscosto` DISABLE KEYS */;
INSERT INTO `tbl_man_centroscosto` (`cCosto_Id`, `cCosto_Nombre`, `cCosto_Estado`) VALUES (1,'Costos variables','A'),(2,'Costos Fijos','A');
/*!40000 ALTER TABLE `tbl_man_centroscosto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_ciudades`
--

DROP TABLE IF EXISTS `tbl_man_ciudades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_ciudades` (
  `ciudad_Id` int(11) NOT NULL AUTO_INCREMENT,
  `ciudad_Nombre` varchar(28) NOT NULL,
  `region_Id` int(11) NOT NULL,
  `ciudad_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`ciudad_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_ciudades`
--

LOCK TABLES `tbl_man_ciudades` WRITE;
/*!40000 ALTER TABLE `tbl_man_ciudades` DISABLE KEYS */;
INSERT INTO `tbl_man_ciudades` (`ciudad_Id`, `ciudad_Nombre`, `region_Id`, `ciudad_Estado`) VALUES (1,'Arica',15,'A'),(2,'Parinacota',15,'A'),(3,'Iquique',1,'A'),(4,'Tamarugal',1,'A'),(5,'Antofagasta',2,'A'),(6,'El Loa',2,'A'),(7,'Tocopilla',2,'A'),(8,'Copiapó',3,'A'),(9,'Chañaral',3,'A'),(10,'Huasco',3,'A'),(11,'Elqui',4,'A'),(12,'Choapa',4,'A'),(13,'Limarí',4,'A'),(14,'Valparaíso',5,'A'),(15,'Isla de Pascua',5,'A'),(16,'Los Andes',5,'A'),(17,'Petorca',5,'A'),(18,'Quillota',5,'A'),(19,'San Antonio',5,'A'),(20,'San Felipe de Aconcagua',5,'A'),(21,'Marga Marga',5,'A'),(22,'Cachapoal',6,'A'),(23,'Cardenal Caro',6,'A'),(24,'Colchagua',6,'A'),(25,'Talca',7,'A'),(26,'Cauquenes',7,'A'),(27,'Curicó',7,'A'),(28,'Linares',7,'A'),(29,'Concepción',8,'A'),(30,'Arauco',8,'A'),(31,'Biobío',8,'A'),(32,'Ñuble',8,'A'),(33,'Cautín',9,'A'),(34,'Malleco',9,'A'),(35,'Valdivia',14,'A'),(36,'Ranco',14,'A'),(37,'Llanquihue',10,'A'),(38,'Chiloé',10,'A'),(39,'Osorno',10,'A'),(40,'Palena',10,'A'),(41,'Coihaique',11,'A'),(42,'Aisén',11,'A'),(43,'Capitán Prat',11,'A'),(44,'General Carrera',11,'A'),(45,'Magallanes',12,'A'),(46,'Antártica Chilena',12,'A'),(47,'Tierra del Fuego',12,'A'),(48,'Última Esperanza',12,'A'),(49,'Santiago',13,'A'),(50,'Cordillera',13,'A'),(51,'Chacabuco',13,'A'),(52,'Maipo',13,'A'),(53,'Melipilla',13,'A'),(54,'Talagante',13,'A');
/*!40000 ALTER TABLE `tbl_man_ciudades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_comunas`
--

DROP TABLE IF EXISTS `tbl_man_comunas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_comunas` (
  `comuna_Id` int(11) NOT NULL AUTO_INCREMENT,
  `comuna_Nombre` varchar(25) NOT NULL,
  `ciudad_Id` int(11) NOT NULL,
  `comuna_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`comuna_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=347 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_comunas`
--

LOCK TABLES `tbl_man_comunas` WRITE;
/*!40000 ALTER TABLE `tbl_man_comunas` DISABLE KEYS */;
INSERT INTO `tbl_man_comunas` (`comuna_Id`, `comuna_Nombre`, `ciudad_Id`, `comuna_Estado`) VALUES (1,'Iquique',3,'A'),(2,'Alto Hospicio',3,'A'),(3,'Pozo Almonte',4,'A'),(4,'Camiña',4,'A'),(5,'Colchane',4,'A'),(6,'Huara',4,'A'),(7,'Pica',4,'A'),(8,'Antofagasta',5,'A'),(9,'Mejillones',5,'A'),(10,'Sierra Gorda',5,'A'),(11,'Taltal',5,'A'),(12,'Calama',6,'A'),(13,'Ollagüe',6,'A'),(14,'San Pedro de Atacama',6,'A'),(15,'Tocopilla',7,'A'),(16,'María Elena',7,'A'),(17,'Copiapó',8,'A'),(18,'Caldera',8,'A'),(19,'Tierra Amarilla',8,'A'),(20,'Chañaral',9,'A'),(21,'Diego de Almagro',9,'A'),(22,'Vallenar',10,'A'),(23,'Alto del Carmen',10,'A'),(24,'Freirina',10,'A'),(25,'Huasco',10,'A'),(26,'La Serena',11,'A'),(27,'Coquimbo',11,'A'),(28,'Andacollo',11,'A'),(29,'La Higuera',11,'A'),(30,'Paihuano',11,'A'),(31,'Vicuña',11,'A'),(32,'Illapel',12,'A'),(33,'Canela',12,'A'),(34,'Los Vilos',12,'A'),(35,'Salamanca',12,'A'),(36,'Ovalle',13,'A'),(37,'Combarbalá',13,'A'),(38,'Monte Patria',13,'A'),(39,'Punitaqui',13,'A'),(40,'Río Hurtado',13,'A'),(41,'Valparaíso',14,'A'),(42,'Casablanca',14,'A'),(43,'Concón',14,'A'),(44,'Juan Fernández',14,'A'),(45,'Puchuncaví',14,'A'),(46,'Quintero',14,'A'),(47,'Viña del Mar',14,'A'),(48,'Isla de Pascua',15,'A'),(49,'Los Andes',16,'A'),(50,'Calle Larga',16,'A'),(51,'Rinconada',16,'A'),(52,'San Esteban',16,'A'),(53,'La Ligua',17,'A'),(54,'Cabildo',17,'A'),(55,'Papudo',17,'A'),(56,'Petorca',17,'A'),(57,'Zapallar',17,'A'),(58,'Quillota',18,'A'),(59,'La Calera',18,'A'),(60,'Hijuelas',18,'A'),(61,'La Cruz',18,'A'),(62,'Nogales',18,'A'),(63,'San Antonio',19,'A'),(64,'Algarrobo',19,'A'),(65,'Cartagena',19,'A'),(66,'El Quisco',19,'A'),(67,'El Tabo',19,'A'),(68,'Santo Domingo',19,'A'),(69,'San Felipe',20,'A'),(70,'Catemu',20,'A'),(71,'Llay Llay',20,'A'),(72,'Panquehue',20,'A'),(73,'Putaendo',20,'A'),(74,'Santa María',20,'A'),(75,'Quilpué',21,'A'),(76,'Limache',21,'A'),(77,'Olmué',21,'A'),(78,'Villa Alemana',21,'A'),(79,'Rancagua',22,'A'),(80,'Codegua',22,'A'),(81,'Coinco',22,'A'),(82,'Coltauco',22,'A'),(83,'Doñihue',22,'A'),(84,'Graneros',22,'A'),(85,'Las Cabras',22,'A'),(86,'Machalí',22,'A'),(87,'Malloa',22,'A'),(88,'Mostazal',22,'A'),(89,'Olivar',22,'A'),(90,'Peumo',22,'A'),(91,'Pichidegua',22,'A'),(92,'Quinta de Tilcoco',22,'A'),(93,'Rengo',22,'A'),(94,'Requínoa',22,'A'),(95,'San Vicente',22,'A'),(96,'Pichilemu',23,'A'),(97,'La Estrella',23,'A'),(98,'Litueche',23,'A'),(99,'Marchihue',23,'A'),(100,'Navidad',23,'A'),(101,'Paredones',23,'A'),(102,'San Fernando',24,'A'),(103,'Chépica',24,'A'),(104,'Chimbarongo',24,'A'),(105,'Lolol',24,'A'),(106,'Nancagua',24,'A'),(107,'Palmilla',24,'A'),(108,'Peralillo',24,'A'),(109,'Placilla',24,'A'),(110,'Pumanque',24,'A'),(111,'Santa Cruz',24,'A'),(112,'Talca',25,'A'),(113,'Constitución',25,'A'),(114,'Curepto',25,'A'),(115,'Empedrado',25,'A'),(116,'Maule',25,'A'),(117,'Pelarco',25,'A'),(118,'Pencahue',25,'A'),(119,'Río Claro',25,'A'),(120,'San Clemente',25,'A'),(121,'San Rafael',25,'A'),(122,'Cauquenes',26,'A'),(123,'Chanco',26,'A'),(124,'Pelluhue',26,'A'),(125,'Curicó',27,'A'),(126,'Hualañé',27,'A'),(127,'Licantén',27,'A'),(128,'Molina',27,'A'),(129,'Rauco',27,'A'),(130,'Romeral',27,'A'),(131,'Sagrada Familia',27,'A'),(132,'Teno',27,'A'),(133,'Vichuquén',27,'A'),(134,'Linares',28,'A'),(135,'Colbún',28,'A'),(136,'Longaví',28,'A'),(137,'Parral',28,'A'),(138,'Retiro',28,'A'),(139,'San Javier',28,'A'),(140,'Villa Alegre',28,'A'),(141,'Yerbas Buenas',28,'A'),(142,'Concepción',29,'A'),(143,'Coronel',29,'A'),(144,'Chiguayante',29,'A'),(145,'Florida',29,'A'),(146,'Hualqui',29,'A'),(147,'Lota',29,'A'),(148,'Penco',29,'A'),(149,'San Pedro de la Paz',29,'A'),(150,'Santa Juana',29,'A'),(151,'Talcahuano',29,'A'),(152,'Tomé',29,'A'),(153,'Hualpén',29,'A'),(154,'Lebu',30,'A'),(155,'Arauco',30,'A'),(156,'Cañete',30,'A'),(157,'Contulmo',30,'A'),(158,'Curanilahue',30,'A'),(159,'Los Álamos',30,'A'),(160,'Tirúa',30,'A'),(161,'Los Ángeles',31,'A'),(162,'Antuco',31,'A'),(163,'Cabrero',31,'A'),(164,'Laja',31,'A'),(165,'Mulchén',31,'A'),(166,'Nacimiento',31,'A'),(167,'Negrete',31,'A'),(168,'Quilaco',31,'A'),(169,'Quilleco',31,'A'),(170,'San Rosendo',31,'A'),(171,'Santa Bárbara',31,'A'),(172,'Tucapel',31,'A'),(173,'Yumbel',31,'A'),(174,'Alto Biobío',31,'A'),(175,'Chillán',32,'A'),(176,'Bulnes',32,'A'),(177,'Cobquecura',32,'A'),(178,'Coelemu',32,'A'),(179,'Coihueco',32,'A'),(180,'Chillán Viejo',32,'A'),(181,'El Carmen',32,'A'),(182,'Ninhue',32,'A'),(183,'Ñiquén',32,'A'),(184,'Pemuco',32,'A'),(185,'Pinto',32,'A'),(186,'Portezuelo',32,'A'),(187,'Quillón',32,'A'),(188,'Quirihue',32,'A'),(189,'Ránquil',32,'A'),(190,'San Carlos',32,'A'),(191,'San Fabián',32,'A'),(192,'San Ignacio',32,'A'),(193,'San Nicolás',32,'A'),(194,'Treguaco',32,'A'),(195,'Yungay',32,'A'),(196,'Temuco',33,'A'),(197,'Carahue',33,'A'),(198,'Cunco',33,'A'),(199,'Curarrehue',33,'A'),(200,'Freire',33,'A'),(201,'Galvarino',33,'A'),(202,'Gorbea',33,'A'),(203,'Lautaro',33,'A'),(204,'Loncoche',33,'A'),(205,'Melipeuco',33,'A'),(206,'Nueva Imperial',33,'A'),(207,'Padre las Casas',33,'A'),(208,'Perquenco',33,'A'),(209,'Pitrufquén',33,'A'),(210,'Pucón',33,'A'),(211,'Saavedra',33,'A'),(212,'Teodoro Schmidt',33,'A'),(213,'Toltén',33,'A'),(214,'Vilcún',33,'A'),(215,'Villarrica',33,'A'),(216,'Cholchol',33,'A'),(217,'Angol',34,'A'),(218,'Collipulli',34,'A'),(219,'Curacautín',34,'A'),(220,'Ercilla',34,'A'),(221,'Lonquimay',34,'A'),(222,'Los Sauces',34,'A'),(223,'Lumaco',34,'A'),(224,'Purén',34,'A'),(225,'Renaico',34,'A'),(226,'Traiguén',34,'A'),(227,'Victoria',34,'A'),(228,'Puerto Montt',37,'A'),(229,'Calbuco',37,'A'),(230,'Cochamó',37,'A'),(231,'Fresia',37,'A'),(232,'Frutillar',37,'A'),(233,'Los Muermos',37,'A'),(234,'Llanquihue',37,'A'),(235,'Maullín',37,'A'),(236,'Puerto Varas',37,'A'),(237,'Castro',38,'A'),(238,'Ancud',38,'A'),(239,'Chonchi',38,'A'),(240,'Curaco de Vélez',38,'A'),(241,'Dalcahue',38,'A'),(242,'Puqueldón',38,'A'),(243,'Queilén',38,'A'),(244,'Quellón',38,'A'),(245,'Quemchi',38,'A'),(246,'Quinchao',38,'A'),(247,'Osorno',39,'A'),(248,'Puerto Octay',39,'A'),(249,'Purranque',39,'A'),(250,'Puyehue',39,'A'),(251,'Río Negro',39,'A'),(252,'San Juan de la Costa',39,'A'),(253,'San Pablo',39,'A'),(254,'Chaitén',40,'A'),(255,'Futaleufú',40,'A'),(256,'Hualaihué',40,'A'),(257,'Palena',40,'A'),(258,'Coyhaique',41,'A'),(259,'Lago Verde',41,'A'),(260,'Aysén',42,'A'),(261,'Cisnes',42,'A'),(262,'Guaitecas',42,'A'),(263,'Cochrane',43,'A'),(264,'O\'Higgins',43,'A'),(265,'Tortel',43,'A'),(266,'Chile Chico',44,'A'),(267,'Río Ibáñez',44,'A'),(268,'Punta Arenas',45,'A'),(269,'Laguna Blanca',45,'A'),(270,'Río Verde',45,'A'),(271,'San Gregorio',45,'A'),(272,'Cabo de Hornos',46,'A'),(273,'Antártica',46,'A'),(274,'Porvenir',47,'A'),(275,'Primavera',47,'A'),(276,'Timaukel',47,'A'),(277,'Natales',48,'A'),(278,'Torres del Paine',48,'A'),(279,'Santiago',49,'A'),(280,'Cerrillos',49,'A'),(281,'Cerro Navia',49,'A'),(282,'Conchalí',49,'A'),(283,'El Bosque',49,'A'),(284,'Estación Central',49,'A'),(285,'Huechuraba',49,'A'),(286,'Independencia',49,'A'),(287,'La Cisterna',49,'A'),(288,'La Florida',49,'A'),(289,'La Granja',49,'A'),(290,'La Pintana',49,'A'),(291,'La Reina',49,'A'),(292,'Las Condes',49,'A'),(293,'Lo Barnechea',49,'A'),(294,'Lo Espejo',49,'A'),(295,'Lo Prado',49,'A'),(296,'Macul',49,'A'),(297,'Maipú',49,'A'),(298,'Ñuñoa',49,'A'),(299,'Pedro Aguirre Cerda',49,'A'),(300,'Peñalolén',49,'A'),(301,'Providencia',49,'A'),(302,'Pudahuel',49,'A'),(303,'Quilicura',49,'A'),(304,'Quinta Normal',49,'A'),(305,'Recoleta',49,'A'),(306,'Renca',49,'A'),(307,'San Joaquín',49,'A'),(308,'San Miguel',49,'A'),(309,'San Ramón',49,'A'),(310,'Vitacura',49,'A'),(311,'Puente Alto',50,'A'),(312,'Pirque',50,'A'),(313,'San José de Maipo',50,'A'),(314,'Colina',51,'A'),(315,'Lampa',51,'A'),(316,'Tiltil',51,'A'),(317,'San Bernardo',52,'A'),(318,'Buin',52,'A'),(319,'Calera de Tango',52,'A'),(320,'Paine',52,'A'),(321,'Melipilla',53,'A'),(322,'Alhué',53,'A'),(323,'Curacaví',53,'A'),(324,'María Pinto',53,'A'),(325,'San Pedro',53,'A'),(326,'Talagante',54,'A'),(327,'El Monte',54,'A'),(328,'Isla de Maipo',54,'A'),(329,'Padre Hurtado',54,'A'),(330,'Peñaflor',54,'A'),(331,'Valdivia',35,'A'),(332,'Corral',35,'A'),(333,'Lanco',35,'A'),(334,'Los Lagos',35,'A'),(335,'Máfil',35,'A'),(336,'Mariquina',35,'A'),(337,'Paillaco',35,'A'),(338,'Panguipulli',35,'A'),(339,'La Unión',36,'A'),(340,'Futrono',36,'A'),(341,'Lago Ranco',36,'A'),(342,'Río Bueno',36,'A'),(343,'Arica',1,'A'),(344,'Camarones',1,'A'),(345,'Putre',2,'A'),(346,'General Lagos',2,'A');
/*!40000 ALTER TABLE `tbl_man_comunas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_mediospago`
--

DROP TABLE IF EXISTS `tbl_man_mediospago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_mediospago` (
  `medioPago_Id` int(11) NOT NULL AUTO_INCREMENT,
  `medioPago_Nombre` varchar(28) NOT NULL,
  `medioPago_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`medioPago_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_mediospago`
--

LOCK TABLES `tbl_man_mediospago` WRITE;
/*!40000 ALTER TABLE `tbl_man_mediospago` DISABLE KEYS */;
INSERT INTO `tbl_man_mediospago` (`medioPago_Id`, `medioPago_Nombre`, `medioPago_Estado`) VALUES (1,'Efectivo','A'),(2,'Transferencia electrónica','A'),(3,'Cheque','A');
/*!40000 ALTER TABLE `tbl_man_mediospago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_origenes`
--

DROP TABLE IF EXISTS `tbl_man_origenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_origenes` (
  `origen_Id` int(11) NOT NULL AUTO_INCREMENT,
  `origen_Nombre` varchar(45) NOT NULL,
  `origen_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`origen_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_origenes`
--

LOCK TABLES `tbl_man_origenes` WRITE;
/*!40000 ALTER TABLE `tbl_man_origenes` DISABLE KEYS */;
INSERT INTO `tbl_man_origenes` (`origen_Id`, `origen_Nombre`, `origen_Estado`) VALUES (1,'Correo Electrónico','A'),(2,'Sistema','A'),(3,'Web','A'),(4,'Teléfono','A');
/*!40000 ALTER TABLE `tbl_man_origenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_paises`
--

DROP TABLE IF EXISTS `tbl_man_paises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_paises` (
  `pais_Id` int(11) NOT NULL AUTO_INCREMENT,
  `pais_Nombre` varchar(40) NOT NULL,
  `pais_Sigla` varchar(5) DEFAULT NULL,
  `pais_Gentilicio` varchar(30) DEFAULT NULL,
  `pais_Estado` enum('A','D') NOT NULL,
  PRIMARY KEY (`pais_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_paises`
--

LOCK TABLES `tbl_man_paises` WRITE;
/*!40000 ALTER TABLE `tbl_man_paises` DISABLE KEYS */;
INSERT INTO `tbl_man_paises` (`pais_Id`, `pais_Nombre`, `pais_Sigla`, `pais_Gentilicio`, `pais_Estado`) VALUES (1,'Afganistán',NULL,NULL,'A'),(2,'Albania',NULL,NULL,'A'),(3,'Alemania',NULL,NULL,'A'),(4,'Andorra',NULL,NULL,'A'),(5,'Angola',NULL,NULL,'A'),(6,'Antigua y Barbuda',NULL,NULL,'A'),(7,'Arabia Saudita',NULL,NULL,'A'),(8,'Argelia',NULL,NULL,'A'),(9,'Argentina',NULL,NULL,'A'),(10,'Armenia',NULL,NULL,'A'),(11,'Australia',NULL,NULL,'A'),(12,'Austria',NULL,NULL,'A'),(13,'Azerbaiyán',NULL,NULL,'A'),(14,'Bahamas',NULL,NULL,'A'),(15,'Bangladés',NULL,NULL,'A'),(16,'Barbados',NULL,NULL,'A'),(17,'Baréin',NULL,NULL,'A'),(18,'Bélgica',NULL,NULL,'A'),(19,'Belice',NULL,NULL,'A'),(20,'Benín',NULL,NULL,'A'),(21,'Bielorrusia',NULL,NULL,'A'),(22,'Birmania',NULL,NULL,'A'),(23,'Bolivia',NULL,NULL,'A'),(24,'Bosnia y Herzegovina',NULL,NULL,'A'),(25,'Botsuana',NULL,NULL,'A'),(26,'Brasil',NULL,NULL,'A'),(27,'Brunéi',NULL,NULL,'A'),(28,'Bulgaria',NULL,NULL,'A'),(29,'Burkina Faso',NULL,NULL,'A'),(30,'Burundi',NULL,NULL,'A'),(31,'Bután',NULL,NULL,'A'),(32,'Cabo Verde',NULL,NULL,'A'),(33,'Camboya',NULL,NULL,'A'),(34,'Camerún',NULL,NULL,'A'),(35,'Canadá',NULL,NULL,'A'),(36,'Catar',NULL,NULL,'A'),(37,'Chad',NULL,NULL,'A'),(38,'Chile','CHI','Chileno','A'),(39,'China',NULL,NULL,'A'),(40,'Chipre',NULL,NULL,'A'),(41,'Ciudad Del Vaticano',NULL,NULL,'A'),(42,'Colombia',NULL,NULL,'A'),(43,'Comoras',NULL,NULL,'A'),(44,'Corea Del Norte',NULL,NULL,'A'),(45,'Corea del sur',NULL,NULL,'A'),(46,'Costa De Marfil',NULL,NULL,'A'),(47,'Costa Rica',NULL,NULL,'A'),(48,'Croacia',NULL,NULL,'A'),(49,'Cuba',NULL,NULL,'A'),(50,'Dinamarca',NULL,NULL,'A'),(51,'Dominica',NULL,NULL,'A'),(52,'Ecuador',NULL,NULL,'A'),(53,'Egipto',NULL,NULL,'A'),(54,'El Salvador',NULL,NULL,'A'),(55,'Emiratos Arabes Unidos',NULL,NULL,'A'),(56,'Eritrea',NULL,NULL,'A'),(57,'Eslovaquia',NULL,NULL,'A'),(58,'Eslovenia',NULL,NULL,'A'),(59,'España',NULL,NULL,'A'),(60,'Estados Unidos',NULL,NULL,'A'),(61,'Estonia',NULL,NULL,'A'),(62,'Etiopía',NULL,NULL,'A'),(63,'Filipinas',NULL,NULL,'A'),(64,'Finlandia',NULL,NULL,'A'),(65,'Fiyi',NULL,NULL,'A'),(66,'Francia',NULL,NULL,'A'),(67,'Gabón',NULL,NULL,'A'),(68,'Gambia',NULL,NULL,'A'),(69,'Georgia',NULL,NULL,'A'),(70,'Ghana',NULL,NULL,'A'),(71,'Granada',NULL,NULL,'A'),(72,'Grecia',NULL,NULL,'A'),(73,'Guatemala',NULL,NULL,'A'),(74,'Guyana',NULL,NULL,'A'),(75,'Guinea',NULL,NULL,'A'),(76,'Guinea Ecuatorial',NULL,NULL,'A'),(77,'Guinea-Bisáu',NULL,NULL,'A'),(78,'Haití',NULL,NULL,'A'),(79,'Honduras',NULL,NULL,'A'),(80,'Hungría',NULL,NULL,'A'),(81,'India',NULL,NULL,'A'),(82,'Indonesia',NULL,NULL,'A'),(83,'Irak',NULL,NULL,'A'),(84,'Irán',NULL,NULL,'A'),(85,'Irlanda',NULL,NULL,'A'),(86,'Islandia',NULL,NULL,'A'),(87,'Islas Marshall',NULL,NULL,'A'),(88,'Islas Salomon',NULL,NULL,'A'),(89,'Israel',NULL,NULL,'A'),(90,'Italia',NULL,NULL,'A'),(91,'Jamaica',NULL,NULL,'A'),(92,'Japón',NULL,NULL,'A'),(93,'Jordania',NULL,NULL,'A'),(94,'Kazajistán',NULL,NULL,'A'),(95,'Kenia',NULL,NULL,'A'),(96,'Kirguistán',NULL,NULL,'A'),(97,'Kiribati',NULL,NULL,'A'),(98,'Kuwait',NULL,NULL,'A'),(99,'Laos',NULL,NULL,'A'),(100,'Lesoto',NULL,NULL,'A'),(101,'Letonia',NULL,NULL,'A'),(102,'Líbano',NULL,NULL,'A'),(103,'Liberia',NULL,NULL,'A'),(104,'Libia',NULL,NULL,'A'),(105,'Liechtenstein',NULL,NULL,'A'),(106,'Lituania',NULL,NULL,'A'),(107,'Luxemburgo',NULL,NULL,'A'),(108,'Madagascar',NULL,NULL,'A'),(109,'Malasia',NULL,NULL,'A'),(110,'Malaui',NULL,NULL,'A'),(111,'Maldivas',NULL,NULL,'A'),(112,'Malí',NULL,NULL,'A'),(113,'Malta',NULL,NULL,'A'),(114,'Marruecos',NULL,NULL,'A'),(115,'Mauricio',NULL,NULL,'A'),(116,'Mauritania',NULL,NULL,'A'),(117,'México',NULL,NULL,'A'),(118,'Micronesia',NULL,NULL,'A'),(119,'Moldavia',NULL,NULL,'A'),(120,'Mónaco',NULL,NULL,'A'),(121,'Mongolia',NULL,NULL,'A'),(122,'Montenegro',NULL,NULL,'A'),(123,'Mozambique',NULL,NULL,'A'),(124,'Namibia',NULL,NULL,'A'),(125,'Nauru',NULL,NULL,'A'),(126,'Nepal',NULL,NULL,'A'),(127,'Nicaragua',NULL,NULL,'A'),(128,'Níger',NULL,NULL,'A'),(129,'Nigeria',NULL,NULL,'A'),(130,'Noruega',NULL,NULL,'A'),(131,'Nueva Zelanda',NULL,NULL,'A'),(132,'Omán',NULL,NULL,'A'),(133,'Países Bajos',NULL,NULL,'A'),(134,'Pakistán',NULL,NULL,'A'),(135,'Palaos',NULL,NULL,'A'),(136,'Panamá',NULL,NULL,'A'),(137,'Papúa Nueva Guinea',NULL,NULL,'A'),(138,'Paraguay',NULL,NULL,'A'),(139,'Perú',NULL,NULL,'A'),(140,'Polonia',NULL,NULL,'A'),(141,'Portugal',NULL,NULL,'A'),(142,'Reino Unido',NULL,NULL,'A'),(143,'República Centro Africana',NULL,NULL,'A'),(144,'República Checa',NULL,NULL,'A'),(145,'República De Macedonia',NULL,NULL,'A'),(146,'República Del Congo',NULL,NULL,'A'),(147,'República Democratica Del Congo',NULL,NULL,'A'),(148,'República Dominicana',NULL,NULL,'A'),(149,'República Sudafricana',NULL,NULL,'A'),(150,'Ruanda',NULL,NULL,'A'),(151,'Rumanía',NULL,NULL,'A'),(152,'Rusia',NULL,NULL,'A'),(153,'Samoa',NULL,NULL,'A'),(154,'San Cristobal y Nieves',NULL,NULL,'A'),(155,'San Marino',NULL,NULL,'A'),(156,'San Vicente y Las Granadinas',NULL,NULL,'A'),(157,'Santa Lucia',NULL,NULL,'A'),(158,'Santo Tome y Principe',NULL,NULL,'A'),(159,'Senegal',NULL,NULL,'A'),(160,'Serbia',NULL,NULL,'A'),(161,'Seychelles',NULL,NULL,'A'),(162,'Sierra Leona',NULL,NULL,'A'),(163,'Singapur',NULL,NULL,'A'),(164,'Siria',NULL,NULL,'A'),(165,'Somalia',NULL,NULL,'A'),(166,'Sri Lanka',NULL,NULL,'A'),(167,'Suazilandia',NULL,NULL,'A'),(168,'Sudán',NULL,NULL,'A'),(169,'Sudán Del Sur',NULL,NULL,'A'),(170,'Suecia',NULL,NULL,'A'),(171,'Suiza',NULL,NULL,'A'),(172,'Surinam',NULL,NULL,'A'),(173,'Tailandia',NULL,NULL,'A'),(174,'Tanzania',NULL,NULL,'A'),(175,'Tayikistán',NULL,NULL,'A'),(176,'Timor Oriental',NULL,NULL,'A'),(177,'Togo',NULL,NULL,'A'),(178,'Tonga',NULL,NULL,'A'),(179,'Trinidad y Tobago',NULL,NULL,'A'),(180,'Túnez',NULL,NULL,'A'),(181,'Turkmenistán',NULL,NULL,'A'),(182,'Turquía',NULL,NULL,'A'),(183,'Tuvalu',NULL,NULL,'A'),(184,'Ucrania',NULL,NULL,'A'),(185,'Uganda',NULL,NULL,'A'),(186,'Uruguay',NULL,NULL,'A'),(187,'Uzbekistán',NULL,NULL,'A'),(188,'Vanuatu',NULL,NULL,'A'),(189,'Venezuela',NULL,NULL,'A'),(190,'Vietnam',NULL,NULL,'A'),(191,'Yemen',NULL,NULL,'A'),(192,'Yibuti',NULL,NULL,'A'),(193,'Zambia',NULL,NULL,'A'),(194,'Zimbabue',NULL,NULL,'A');
/*!40000 ALTER TABLE `tbl_man_paises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_regiones`
--

DROP TABLE IF EXISTS `tbl_man_regiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_regiones` (
  `region_Id` int(11) NOT NULL AUTO_INCREMENT,
  `pais_Id` int(11) NOT NULL,
  `region_Nombre` varchar(50) NOT NULL,
  `region_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`region_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_regiones`
--

LOCK TABLES `tbl_man_regiones` WRITE;
/*!40000 ALTER TABLE `tbl_man_regiones` DISABLE KEYS */;
INSERT INTO `tbl_man_regiones` (`region_Id`, `pais_Id`, `region_Nombre`, `region_Estado`) VALUES (1,38,'Región de Tarapacá','A'),(2,38,'Región de Antofagasta','A'),(3,38,'Región de Atacama','A'),(4,38,'Región de Coquimbo','A'),(5,38,'Región de Valparaíso','A'),(6,38,'Región del Libertador Gral. Bernardo O’Higgins','A'),(7,38,'Región del Maule','A'),(8,38,'Región del Biobío','A'),(9,38,'Región de la Araucanía','A'),(10,38,'Región de Los Lagos','A'),(11,38,'Región Aisén del Gral. Carlos Ibáñez del Campo','A'),(12,38,'Región de Magallanes y de la Antártica Chilena','A'),(13,38,'Región Metropolitana de Santiago','A'),(14,38,'Región de Los Ríos','A'),(15,38,'Región de Arica y Parinacota','A');
/*!40000 ALTER TABLE `tbl_man_regiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_servicios`
--

DROP TABLE IF EXISTS `tbl_man_servicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_servicios` (
  `servicio_Id` int(11) NOT NULL AUTO_INCREMENT,
  `servicio_Nombre` varchar(50) NOT NULL,
  `servicio_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`servicio_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_servicios`
--

LOCK TABLES `tbl_man_servicios` WRITE;
/*!40000 ALTER TABLE `tbl_man_servicios` DISABLE KEYS */;
INSERT INTO `tbl_man_servicios` (`servicio_Id`, `servicio_Nombre`, `servicio_Estado`) VALUES (1,'Seguridad 24 hrs.','A'),(2,'Cuarto baño privado','A'),(3,'TV cable y WIFI','A'),(4,'Quincho','A');
/*!40000 ALTER TABLE `tbl_man_servicios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_tarifas`
--

DROP TABLE IF EXISTS `tbl_man_tarifas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_tarifas` (
  `tarifa_Id` int(11) NOT NULL AUTO_INCREMENT,
  `tarifa_Tipo` enum('P','E') NOT NULL,
  `tarifa_CantPersonas` int(11) NOT NULL,
  `tarifa_Valor` int(11) NOT NULL,
  `tarifa_Estado` enum('A','D') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`tarifa_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_tarifas`
--

LOCK TABLES `tbl_man_tarifas` WRITE;
/*!40000 ALTER TABLE `tbl_man_tarifas` DISABLE KEYS */;
INSERT INTO `tbl_man_tarifas` (`tarifa_Id`, `tarifa_Tipo`, `tarifa_CantPersonas`, `tarifa_Valor`, `tarifa_Estado`) VALUES (1,'P',1,55000,'A'),(2,'P',2,55000,'A'),(3,'P',3,55000,'A'),(4,'P',4,65000,'A'),(5,'P',5,75000,'A'),(6,'P',6,85000,'A'),(7,'P',7,95000,'A'),(8,'P',8,105000,'A'),(9,'P',9,115000,'A'),(10,'P',6,400000,'D'),(11,'E',6,550000,'A'),(12,'P',1,11000,'A');
/*!40000 ALTER TABLE `tbl_man_tarifas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_man_tiposdocumento`
--

DROP TABLE IF EXISTS `tbl_man_tiposdocumento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_man_tiposdocumento` (
  `tipoDoc_Id` int(11) NOT NULL AUTO_INCREMENT,
  `tipoDoc_Nombre` varchar(40) NOT NULL,
  `tipoDoc_Sigla` varchar(3) DEFAULT NULL,
  `tipoDoc_Eliminar` enum('S','N') NOT NULL DEFAULT 'S',
  `tipoDoc_Estado` enum('A','D') NOT NULL,
  PRIMARY KEY (`tipoDoc_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_man_tiposdocumento`
--

LOCK TABLES `tbl_man_tiposdocumento` WRITE;
/*!40000 ALTER TABLE `tbl_man_tiposdocumento` DISABLE KEYS */;
INSERT INTO `tbl_man_tiposdocumento` (`tipoDoc_Id`, `tipoDoc_Nombre`, `tipoDoc_Sigla`, `tipoDoc_Eliminar`, `tipoDoc_Estado`) VALUES (1,'(33) Factura electrónica','FEC','S','A'),(2,'Abono estadía','ABE','S','A'),(3,'Boleta','BOL','S','A'),(4,'Reservas','RES','N','A');
/*!40000 ALTER TABLE `tbl_man_tiposdocumento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_res_reservas`
--

DROP TABLE IF EXISTS `tbl_res_reservas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_res_reservas` (
  `reserva_Id` int(11) NOT NULL AUTO_INCREMENT,
  `reserva_FechaCrea` datetime NOT NULL,
  `reserva_UsuarioCrea` varchar(45) DEFAULT NULL,
  `reserva_Estado` enum('R','A') NOT NULL DEFAULT 'A' COMMENT 'R=RESERVADA,A=ACTIVA',
  `cliente_Tipo` enum('P','E') NOT NULL,
  `cliente_Id` int(11) DEFAULT NULL,
  `nacionalidad_Id` int(11) DEFAULT NULL,
  `cliente_Rut` varchar(9) NOT NULL,
  `cliente_Nombres` varchar(40) NOT NULL,
  `cliente_ApellidoPaterno` varchar(15) NOT NULL,
  `cliente_ApellidoMaterno` varchar(15) NOT NULL,
  `pais_Id` int(11) DEFAULT NULL,
  `region_Id` int(11) DEFAULT NULL,
  `ciudad_Id` int(11) DEFAULT NULL,
  `comuna_Id` int(11) DEFAULT NULL,
  `cliente_Direccion` varchar(60) DEFAULT NULL,
  `cliente_CorreoElectronico` varchar(45) NOT NULL,
  `cliente_TelefonoFijo` varchar(15) DEFAULT NULL,
  `cliente_Celular` varchar(15) NOT NULL,
  `propiedad_Id` int(11) NOT NULL,
  `reserva_FechaDesde` date NOT NULL,
  `reserva_FechaHasta` date NOT NULL,
  `reserva_HoraLlegada` varchar(5) NOT NULL,
  `reserva_HoraSalida` varchar(5) NOT NULL,
  `reserva_Adultos` int(11) NOT NULL,
  `reserva_Ninos` int(11) NOT NULL,
  `origen_Id` int(11) NOT NULL,
  `reserva_EstadoComercial` enum('PP','PA') NOT NULL DEFAULT 'PP',
  PRIMARY KEY (`reserva_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_res_reservas`
--

LOCK TABLES `tbl_res_reservas` WRITE;
/*!40000 ALTER TABLE `tbl_res_reservas` DISABLE KEYS */;
INSERT INTO `tbl_res_reservas` (`reserva_Id`, `reserva_FechaCrea`, `reserva_UsuarioCrea`, `reserva_Estado`, `cliente_Tipo`, `cliente_Id`, `nacionalidad_Id`, `cliente_Rut`, `cliente_Nombres`, `cliente_ApellidoPaterno`, `cliente_ApellidoMaterno`, `pais_Id`, `region_Id`, `ciudad_Id`, `comuna_Id`, `cliente_Direccion`, `cliente_CorreoElectronico`, `cliente_TelefonoFijo`, `cliente_Celular`, `propiedad_Id`, `reserva_FechaDesde`, `reserva_FechaHasta`, `reserva_HoraLlegada`, `reserva_HoraSalida`, `reserva_Adultos`, `reserva_Ninos`, `origen_Id`, `reserva_EstadoComercial`) VALUES (2,'2020-10-13 15:39:50','4','A','E',7,38,'764940873','sunor ltda',' Obras de ing ','',38,1,3,1,'','cbarnao@sunor.cl',' Calle Nueva UN','956589321',3,'2020-10-13','2020-11-14','14:00','12:00',2,0,4,'PA'),(3,'2020-10-13 15:41:58','4','A','E',8,38,'764940873','SUNOR LTDA',' Obras ING','',38,1,3,1,' Calle Nueva Uno 4921','cbarnao@sunor.cl','','956589321',4,'2020-10-13','2020-11-14','14:00','12:00',2,0,4,'PA'),(7,'2020-11-03 09:45:11','4','A','P',11,38,'132167060','Luis Alejandro','Sierra','Quispe ',38,2,NULL,NULL,'','luissierra282@gmail.com','','994156041',1,'2020-11-11','2020-11-12','14:00','12:00',3,2,4,'PA'),(8,'2020-11-03 09:46:49','4','A','P',12,38,'159109135','Cristian Andres',' Ojeda ','Ojeda',38,2,NULL,NULL,'','cristian_calama@hotmail.com','','994156041',2,'2020-11-11','2020-11-12','14:00','12:00',3,2,4,'PA'),(9,'2020-11-10 17:11:08','4','A','E',7,38,'764940873','sunor ltda',' Obras de ing ','',38,1,3,1,'','cbarnao@sunor.cl',' Calle Nueva UN','956589321',3,'2020-11-15','2020-11-20','14:00','12:00',2,0,4,'PA'),(10,'2020-11-10 17:12:07','4','A','E',7,38,'764940873','sunor ltda',' Obras de ing ','',38,1,3,1,'','cbarnao@sunor.cl',' Calle Nueva UN','956589321',4,'2020-11-15','2020-11-20','14:00','12:00',2,0,4,'PA'),(11,'2020-11-11 09:35:52','4','A','P',13,38,'19436322-','Gabriela Paz','Figueroa','Osorio',38,1,3,NULL,' Edificio Playa Huantajaya 2030','nicoleot@gmail.com','','961084085',1,'2020-11-13','2020-11-14','14:00','12:00',2,2,4,'PA'),(12,'2020-11-11 12:16:21','4','A','P',14,38,'18503607-','Rosrigo Esteban ','Vergara','Viza',38,1,3,2,'Cale 1 numero 4610 la tortuga Alto Hospicio','rvergraviza21@gmail.com','','990506043',2,'2020-11-13','2020-11-14','14:00','12:00',5,2,3,'PA'),(13,'2020-11-15 21:18:17','4','A','P',15,38,'17852649-','Danitza ','Barrios ','Farias',38,1,3,1,'Recabarren 2779','danitzabafa@gmail.com','','982616871',5,'2020-11-16','2020-11-16','14:00','12:00',5,0,4,'PA'),(14,'2020-11-17 12:55:06','4','A','P',15,38,'17852649-','Danitza ','Barrios ','Farias',38,1,3,1,'Recabarren 2779','danitzabafa@gmail.com','','982616871',5,'2020-11-17','2020-11-17','14:00','12:00',5,0,4,'PA'),(15,'2020-11-17 13:06:10','4','A','P',16,38,'18262561-','Diego Maximiliano','Burgos ','Lquiz',38,1,3,1,'Los Chunchos 3982','diego23177@hotmail.com','','944073887',2,'2020-11-16','2020-11-16','14:00','12:00',2,1,4,'PA'),(19,'2020-12-05 16:17:24','0','A','E',20,38,'191798147','Javiera ','Valenzuela','Cuellar',38,1,3,2,'Ac parque 2 3243','javieravc1504@gmail.com','','982020660',3,'2021-01-01','2021-01-03','14:00','12:00',7,0,3,'PA'),(21,'2020-12-07 18:32:05','0','A','',22,38,'17431148-','Paulina Isabel','Taboada ',' Tobar',38,15,1,343,'Santiago Arata Gandolfo #4305','pau.taboada22@gmail.com','','962283444',4,'2021-01-01','2021-01-03','14:00','12:00',4,4,3,'PA'),(26,'2020-12-08 19:50:32','4','A','P',25,38,'00000000','Roxana ','Cerda','',38,1,3,1,'','roxana.cerda@gmail.com','','962494294',3,'2020-12-18','2020-12-19','14:00','12:00',4,1,4,'PA'),(27,'2020-12-10 20:30:26','4','A','P',27,38,'189001762','Giresse Alejandra','Aguirre','Leiva',38,1,3,1,' Tamarugal 2993 depto 195','giresseaaguirre@gmail.com','','988275217',2,'2020-12-18','2020-12-19','14:00','12:00',5,0,3,'PA'),(28,'2020-12-11 09:11:46','4','A','P',28,38,'117533743','Rodrigo','Vergara','Allendes',38,1,3,1,'','socomin2013@gmail.com','','940734109',5,'2021-01-01','2021-01-02','14:00','12:00',4,2,3,'PP'),(29,'2020-12-14 19:21:35','4','A','P',30,38,'12608066-','David Samuel','Bugueño','Mamani',38,15,1,343,'','david.b.33@hotmail.com','','988334428',5,'2020-12-18','2020-12-19','14:00','12:00',2,3,4,'PA'),(30,'2020-12-15 11:53:15','4','A','P',31,38,'16592293k','Giselle ','Salinas ','Morales',38,1,3,2,'El Alto 2271 Block 13 depto 402','giselle.salinas.m@gmail.com','','967767482',6,'2020-12-18','2020-12-20','14:00','12:00',4,2,4,'PP'),(31,'2020-12-15 15:11:44','4','A','P',32,38,'12763136-','Rodolfo','Muñoz','Gonzalez',38,1,3,1,' Grumete Bolado 63','rmunoz@gmail.es','','979129996',2,'2020-12-31','2021-01-02','14:00','12:00',2,3,4,'PA'),(32,'2020-12-15 15:13:44','4','A','P',33,38,'119049741','Paola ','Rubio ','Ruiz',38,1,3,1,'Grumete Bolados 63 block 3 depto 44','paolarubioestilista@gmail.com','','993735595',1,'2020-12-31','2021-01-02','14:00','12:00',2,2,4,'PA'),(33,'2020-12-17 10:57:00','4','A','P',34,38,'165929047','Crystal ','Figueroa','',38,1,3,1,'el tamarugal 2993','figueroacrystal2@gmail.com','','956899644',4,'2020-12-18','2020-12-19','14:00','12:00',2,3,4,'PA'),(39,'2021-01-04 09:44:08','4','A','P',33,38,'119049741','Paola ','Rubio ','Ruiz',38,1,3,1,'Grumete Bolados 63 block 3 depto 44','paolarubioestilista@gmail.com','','993735595',2,'2021-01-03','2021-01-04','14:00','12:00',7,0,4,'PA'),(40,'2021-01-04 09:50:07','4','A','P',39,38,'10644073-','Rosa','Godoy',' Saez',38,15,1,343,'Olivarera de azapa 2377','cabanas.kiwiland@gmail.com','','971907016',5,'2021-01-04','2021-01-05','15:00','12:00',3,2,4,'PA'),(41,'2021-01-04 09:51:51','4','A','P',40,38,'13640231-','Andrea ','gODOY ','Saez',38,15,1,343,'Orozimbo Barboza 2654','cabanas.kiwiland@gmail.com','','971907016',4,'2021-01-04','2021-01-05','15:00','12:00',4,2,4,'PP'),(42,'2021-01-04 09:59:39','4','A','P',41,38,'12612077-','Javier','Quevedo',' Gonzalez',38,15,1,343,'Sant Ines 4270','cabanas.kiwiland@gmail.com','','979993995',6,'2021-01-03','2021-01-03','14:00','12:00',8,0,4,'PA'),(43,'2021-01-04 10:02:03','4','A','P',42,38,'170925580','Carlos ','Aguilera ','Figueroa',38,2,7,15,'','cabanas.kiwiland@gmail.com','','981403571',3,'2021-01-04','2021-01-04','14:00','12:00',4,1,4,'PA'),(44,'2021-01-04 17:10:25','4','A','P',43,38,'19734128-','Ada','Araya ','Carvajal',38,1,4,3,' Hector Basualto 1031 villa milenium','michii_17_@hotmail.com','','942958213',6,'2021-01-08','2021-01-09','15:00','12:00',5,1,4,'PP'),(45,'2021-01-04 17:12:34','4','A','P',44,38,'17555457-','Kihara ','San Francisco','',38,15,1,343,' Libertad 2273','kiharasanfrancisco@gmail.com','','965527661',8,'2021-01-04','2021-01-04','15:00','12:00',2,1,4,'PA'),(46,'2021-01-04 20:44:14','4','A','P',45,38,'17388662-','Anita','Jorquera ','Aguilera',38,1,4,3,' Libertad 891','maria.aguilera.jorquera@gmail.com','','940435931',1,'2021-01-05','2021-01-05','15:00','12:00',2,2,4,'PA'),(47,'2021-01-05 08:30:50','4','A','P',25,38,'00000000','Roxana ','Cerda','',38,1,3,1,'','roxana.cerda@gmail.com','','962494294',3,'2021-01-08','2021-01-09','15:00','12:00',2,1,4,'PA'),(49,'2021-01-05 08:35:44','4','A','P',47,38,'10214470-',' Patricia ','Muñoz','Olivares',38,1,4,3,' Negreiros 664 Villa Santa Ana','ncortesmu@gmail.com','','950990140',5,'2021-01-09','2021-01-11','15:00','12:00',5,1,4,'PP'),(50,'2021-01-05 08:43:55','4','A','P',48,38,'16349316-',' Natalia','Cortes','Muñoz',38,1,NULL,NULL,'negreiros 664 villa santa ana','ncortesmu@gmail.com','','950990140',4,'2021-01-09','2021-01-11','15:00','12:00',3,2,4,'PA'),(52,'2021-01-05 22:15:03','4','A','P',50,38,'121731355','Ruben','Concha ','Cabrera',38,15,1,343,'cienfuegos 1462','rubencabreraconcha@gmail.com','','975254881',3,'2021-01-05','2021-01-05','15:00','12:00',2,0,4,'PA'),(54,'2021-01-07 09:16:52','4','A','P',50,38,'121731355','Ruben','Concha ','Cabrera',38,15,1,343,'cienfuegos 1462','rubencabreraconcha@gmail.com','','975254881',3,'2021-01-06','2021-01-07','14:00','12:00',2,0,4,'PA'),(55,'2021-01-07 09:28:00','4','A','P',53,38,'12609676-','Cristian ','Cortes','',38,15,1,343,' Jose Morales 4319','corrtee.oo@gmail.com','','948467988',3,'2021-01-12','2021-01-12','15:00','12:00',4,2,4,'PP'),(57,'2021-01-07 16:16:36','4','A','P',56,38,'14223066-','Ruben','Carvajal',' Salazar',38,1,4,3,' Juan Martinez 215 Villa Militar Baquedano','eventosgastronomicos13@gmail.com','','988670875',2,'2021-01-08','2021-01-09','15:00','12:00',3,0,3,'PA'),(58,'2021-01-08 10:01:49','4','A','P',50,38,'121731355','Ruben','Concha ','Cabrera',38,15,1,343,'cienfuegos 1462','rubencabreraconcha@gmail.com','','975254881',4,'2021-01-08','2021-01-08','14:00','12:00',2,0,4,'PA'),(62,'2021-01-09 11:57:44','4','A','P',50,38,'121731355','Ruben','Concha ','Cabrera',38,15,1,343,'cienfuegos 1462','rubencabreraconcha@gmail.com','','975254881',1,'2021-01-09','2021-01-09','14:00','12:00',4,0,4,'PA'),(67,'2021-01-10 10:10:23','4','A','P',64,38,'12937934-','Juan','Figueroa ','Ramirez',38,2,7,15,' Combate de la concepcion 596','j_f_r_76@hotmail.com','','977620336',2,'2021-01-10','2021-01-10','15:00','12:00',4,1,4,'PA'),(68,'2021-01-10 10:12:08','4','A','P',65,38,'12347348-','Marco ','Aguirre','Gomez',38,2,7,15,'Teniente Merino 09','fitodomi1973@gmail.com','','977620336',3,'2021-01-10','2021-01-10','15:00','12:00',4,1,4,'PA'),(69,'2021-01-11 09:52:43','4','A','P',66,38,'15070022-','Hector','Cuevas ','Reyes',38,15,1,343,' Agustin Caballero 2550','hectorcuevasreyes@gmail.com','','951974515',1,'2021-01-12','2021-01-13','15:00','12:00',2,0,4,'PA'),(70,'2021-01-11 09:55:10','4','A','P',67,38,'14237845-','Marco','Rivera','Romero',38,2,7,15,' Pasaje Calama 2757 Villa Los Andea','electrmar@hotmail.com','','950398550',6,'2021-01-12','2021-01-15','15:00','12:00',6,1,4,'PA'),(71,'2021-01-11 09:57:12','4','A','P',68,38,'13005290','Pablo','Cortes','-',38,15,1,343,'San Ignacio Loyola 850 block D depto 203','corrtee.99@gmail.com','','948467988',4,'2021-01-12','2021-01-12','15:00','12:00',3,3,4,'PP'),(72,'2021-01-11 09:59:48','4','A','P',69,38,'18898969-','Nadine ','Vargas ','Mejias',38,1,4,7,'Los Mangos 64','nvargasmejias@gmail.com','','987025073',4,'2021-01-18','2021-01-19','15:00','12:00',4,0,4,'PA'),(73,'2021-01-11 16:29:51','4','A','P',60,38,'12426295-','Mauricio ','Veas','',38,2,5,8,'anacleto solorza 9780','mauroveasp@gmail.com','','940106989',2,'2021-01-13','2021-01-15','15:00','12:00',2,2,4,'PA'),(74,'2021-01-13 15:48:28','4','A','P',70,38,'16253744-',' Francisca ','Donoso',' Gonzalez',38,1,3,1,' Padre  Hurtado2369 Torre Norte DEPTO 1702','donosogonzalez.fran@gmail.com','','956471502',4,'2021-01-13','2021-01-14','15:00','12:00',2,1,4,'PA'),(75,'2021-01-13 15:52:13','4','A','P',71,38,'14103792-','Rodrigo ','Espinola ','Fuentes',38,1,4,3,'mamiña 743','r_espinola@live.cl','','956936222',5,'2021-01-15','2021-01-17','15:00','12:00',2,0,3,'PA'),(76,'2021-01-13 16:06:09','4','A','P',72,38,'16772453-','Yoceling','Alfaro','Arias',38,15,1,343,' colina 1918','yoceling.alfaro@gmail.com','','952145670',3,'2021-01-13','2021-01-14','15:00','12:00',2,1,4,'PA'),(77,'2021-01-14 16:51:39','4','A','P',73,38,'17094166-','Tatiano ','Pizarro ','Morales',38,2,7,15,' Avenida Nuva oriente 2878','tatiana.pizarro@gmail.com','','966892262',3,'2021-01-15','2021-01-16','15:00','12:00',2,2,4,'PA'),(78,'2021-01-18 10:35:55','4','A','P',74,38,'15692851-','Teresa','Caceres','Macpherson',38,15,1,343,'Oozimbo barboza3722','prof.teresacaceres@hotmail.com','','944301134',3,'2021-01-19','2021-01-19','15:00','12:00',2,2,4,'PA'),(80,'2021-01-18 21:56:44','4','A','P',78,38,'18829938-',' Ruben ','Gacitua ',' Gonzalez',38,13,49,279,'San Rosendo 1388 block E  depto 23','ruben.agacitua@gmail.com','','984266368',6,'2021-01-19','2021-01-19','15:00','12:00',6,0,4,'PP'),(81,'2021-01-22 12:37:07','4','A','P',75,38,'13008936-','Jaime Alex','Oropessa ','Pereira',38,1,3,2,' Puerto Varas 4529','alexoropessa@gmail.com','','965059893',2,'2021-01-18','2021-01-19','15:00','12:00',4,2,4,'PP'),(82,'2021-01-22 12:40:25','4','A','P',78,38,'18829938-',' Ruben ','Gacitua ',' Gonzalez',38,13,49,279,'San Rosendo 1388 block E  depto 23','ruben.agacitua@gmail.com','','984266368',6,'2021-01-20','2021-01-20','15:00','12:00',5,1,4,'PP'),(83,'2021-01-22 12:42:33','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',1,'2021-01-19','2021-01-19','14:00','12:00',2,0,4,'PA'),(84,'2021-01-22 12:45:14','4','A','P',69,38,'18898969-','Nadine ','Vargas ','Mejias',38,1,4,7,'Los Mangos 64','nvargasmejias@gmail.com','','987025073',5,'2021-01-18','2021-01-18','14:00','12:00',1,0,4,'PA'),(90,'2021-01-28 11:19:35','4','A','P',85,38,'159758648','Nathalie ','Huerta','',38,2,7,15,' 18 de mayo 766 villa chuquicamata','nhuerta175@gmail.com','','945527592',6,'2021-01-29','2021-02-01','15:00','12:00',6,3,4,'PP'),(92,'2021-02-03 11:27:50','4','A','P',87,38,'135387040','Jose Mauricio','Tapia ','Diaz',38,2,7,15,'Huaman 613','josetapiadiaz11@gmail.com','','942487733',8,'2021-02-05','2021-02-08','15:00','12:00',3,2,4,'PA'),(93,'2021-02-03 11:33:03','4','A','P',88,38,'180170804','Jacqueline ','Sanchez','Esteban',38,1,4,3,' Arica 670','jaque.saanchez@gmail.com','','958616188',6,'2021-02-05','2021-02-06','15:00','12:00',4,0,4,'PA'),(94,'2021-02-03 11:36:19','4','A','P',89,38,'17937556-','Katherine','Matinez','Vega',38,2,5,8,'av huamachuco 8833','k.martinez.vega91@gmail.com','','977697995',3,'2021-02-18','2021-02-20','15:00','12:00',4,0,2,'PA'),(95,'2021-02-08 14:35:05','4','A','P',90,38,'17430958-','Camilo','Soto Cuevas','',38,1,3,2,'Av Las Parcelas 4010','camiloenriquesoto@gmail.com','','942396814',1,'2021-02-08','2021-02-08','15:00','12:00',2,2,3,'PA'),(96,'2021-02-08 14:38:38','4','A','P',91,38,'159722910','Carla ','Marin ','Herrera',38,1,3,1,'Dos Oriente 4649','carla.marin.herrera@gmail.com','','994965912',2,'2021-02-08','2021-02-09','15:00','12:00',2,2,4,'PA'),(98,'2021-02-08 14:46:12','4','A','P',93,38,'10228632-','Adolfo ','Guerra','Sepulveda',38,1,3,2,' Villa Frey3 3302','adolfoturoguerra@gmail.com','','937068878',2,'2021-02-12','2021-02-13','15:00','12:00',3,1,4,'PA'),(99,'2021-02-08 14:48:18','4','A','P',94,38,'17131763','Consuelo','Guerra ','Sepulveda',38,1,3,2,'Villa Frey calle 3 3298','insudentgyg@gmail.com','','937068878',1,'2021-02-12','2021-02-13','15:00','12:00',4,0,4,'PA'),(100,'2021-02-08 14:53:00','4','A','P',95,38,'q6866466-','Milenka ','Aguirre','',38,1,3,2,'','milenka.next.21@gmail.com','','978705499',3,'2021-02-12','2021-02-13','15:00','12:00',2,2,3,'PA'),(101,'2021-02-09 17:39:21','4','A','P',97,38,'185062805','Salomea','Estay','',38,1,3,1,'calcopirita 4239','salome.estay@gmail.com','','998206647',5,'2021-02-12','2021-02-13','15:00','12:00',2,1,4,'PA'),(102,'2021-02-09 17:41:32','4','A','P',98,38,'159503275','Marcia ','Flores','Filgueira',38,1,3,1,' Violeta Parra 4008','flores.filgueira@gmail.com','','986962116',4,'2021-02-12','2021-02-13','15:00','12:00',2,2,4,'PA'),(103,'2021-02-11 11:27:01','4','A','P',99,38,'163503654','Valeria jesus','Olivero','Herrera',38,1,3,1,'General Ibañez','voliveroh@gmail.com','','956486091',5,'2021-02-17','2021-02-18','15:00','12:00',3,1,4,'PA'),(104,'2021-02-11 11:34:39','4','A','P',100,38,'187443598','Natalia ','Miranda','Soto',38,1,3,2,' Calle 2 3717 La tortuga','nataliamiranda164@gmail.com','','967480403',3,'2021-02-27','2021-02-28','15:00','12:00',2,2,4,'PA'),(105,'2021-02-11 17:22:46','4','A','P',101,38,'178400584','Barbara','Peña','',38,1,3,1,' Via Local 2 4057depto 13','pcarrionbarbara@gmail.com','','942637933',1,'2021-02-16','2021-02-17','15:00','12:00',4,0,4,'PA'),(106,'2021-02-17 11:17:59','4','A','P',102,38,'159503275','Marcia','flores','Filgueira',38,1,3,2,'Violeta Parra 4008','flores.filgueira@gmail.com','','986962116',4,'2021-02-15','2021-02-16','15:00','12:00',2,2,4,'PA'),(107,'2021-02-17 11:24:47','4','A','P',103,38,'14599577','Sergio ','Vidal','',38,1,3,1,'av francisco bilbao 3421','sergiovidalbasai@gmail.com','','999927110',4,'2021-02-17','2021-02-18','15:00','12:00',2,2,4,'PA'),(108,'2021-02-17 11:35:45','4','A','P',104,38,'160568208',' Jose Luis ','Contreras ','Mamani',38,1,3,2,'av detective jose cubillos 3430 block 8 depto 202','joseluiscontreras.trabajo@gmail.com','','955268106',2,'2021-02-17','2021-02-18','15:00','12:00',3,3,4,'PP'),(109,'2021-02-17 11:42:27','4','A','P',105,38,'169087954',' Robert Cristian',' Riquelme','',38,1,3,1,' Condominio Altos de Huayquique  av la tirana  4865 depto 66','robert.riquelme.g@gmail.com','','945397467',6,'2021-02-19','2021-02-20','15:00','12:00',4,1,4,'PA'),(110,'2021-02-17 11:45:53','4','A','P',25,38,'00000000','Roxana ','Cerda','',38,1,3,1,'','roxana.cerda@gmail.com','','962494294',5,'2021-02-19','2021-02-20','15:00','12:00',5,0,4,'PA'),(111,'2021-02-17 12:05:46','4','A','P',106,38,'178008730','Nicole','Ceballos','',38,1,3,1,' Libertal 1922','nicolceballosu@gmail.com','','988245503',3,'2021-02-22','2021-02-24','15:00','12:00',5,1,4,'PP'),(112,'2021-02-17 12:10:28','4','A','P',107,38,'174616428','Sergio','Sanzana','',38,1,3,2,'cerro esmeralda 2836','ssanzanag@investigaciones.cl','','965706341',6,'2021-02-22','2021-02-23','15:00','12:00',5,3,4,'PA'),(113,'2021-02-17 13:04:27','4','A','P',108,38,'135082023','Marcela ','Garcia','',38,1,3,1,'Salvador Allende 855','garciaov12@gmail.com','','993085892',2,'2021-02-22','2021-02-23','15:00','12:00',2,2,4,'PA'),(114,'2021-02-17 13:07:49','4','A','P',109,38,'168647190','Nadia ','Aguilera ','Mondac',38,1,3,1,'av arturo prat block 699 depto 12','nadia.aguileramondaca@gmail.com','','996804139',1,'2021-02-23','2021-02-24','15:00','12:00',2,2,4,'PA'),(115,'2021-02-17 13:10:28','4','A','P',110,38,'182634964','Macarena ','Castillo ','Cortes',38,1,3,1,'Moises Gonzales 1601','castillocm19@gmail.com','','999309213',4,'2021-02-23','2021-02-24','15:00','12:00',1,1,4,'PA'),(116,'2021-02-17 13:11:45','4','A','E',79,38,'76924391-',' Productora  Perro Andante E.I.R.L','Teatro ','',38,1,3,NULL,' Los moreños 2877 ','teatroperroandante@gmail.com','','958400322',1,'2021-02-25','2021-02-26','15:00','12:00',2,0,4,'PA'),(117,'2021-02-17 13:12:25','4','A','E',81,38,'76924392-','Productora perro andante E.I.R.L','actividades de ','',38,1,3,1,' Los moreños 2877 ','teatroperroandante@gmail.com','','958400322',2,'2021-02-25','2021-02-26','15:00','12:00',2,2,4,'PA'),(118,'2021-02-17 13:13:03','4','A','E',79,38,'76924391-',' Productora  Perro Andante E.I.R.L','Teatro ','',38,1,3,NULL,' Los moreños 2877 ','teatroperroandante@gmail.com','','958400322',6,'2021-02-25','2021-02-26','15:00','12:00',2,2,4,'PA'),(119,'2021-02-17 13:13:54','4','A','E',79,38,'76924391-',' Productora  Perro Andante E.I.R.L','Teatro ','',38,1,3,NULL,' Los moreños 2877 ','teatroperroandante@gmail.com','','958400322',3,'2021-02-25','2021-02-26','15:00','12:00',2,2,4,'PA'),(120,'2021-02-17 13:14:39','4','A','E',79,38,'76924391-',' Productora  Perro Andante E.I.R.L','Teatro ','',38,1,3,NULL,' Los moreños 2877 ','teatroperroandante@gmail.com','','958400322',4,'2021-02-25','2021-02-26','15:00','12:00',2,2,4,'PA'),(121,'2021-02-17 13:18:23','4','A','P',111,38,'75777884',' syliva ','Rosas',' Urra',38,1,3,1,'grumete bolados 168 ','pivyta@gmail.com','','956983397',4,'2021-02-27','2021-03-01','15:00','12:00',2,2,4,'PA'),(124,'2021-02-19 13:29:21','4','A','P',114,38,'16704798','Nathaly','Pizarro','Ordoñez',38,1,3,2,'rio maipo 3036','nathalypizarro26@gmail.com','','961761493',1,'2021-02-19','2021-02-20','15:00','12:00',6,1,3,'PA'),(125,'2021-02-19 13:31:11','4','A','P',115,38,'182648744','Juan Pablo','Pizarro','Ordoñez',38,1,3,2,'av gabriela mistral 3924','nathalypizarro26@gmail.com','','961761493',4,'2021-02-19','2021-02-20','15:00','12:00',5,2,4,'PA'),(126,'2021-02-19 13:33:45','4','A','P',116,38,'122161315','Patricio','Araya','',38,2,5,8,' sendero del sol 456 casa 41','pato.araya1521@gmail.com','','954237058',4,'2021-02-21','2021-02-22','15:00','12:00',3,2,4,'PA'),(127,'2021-02-19 13:36:01','4','A','P',117,38,'132149666','Gissel ','GOody','Riquelme',38,1,3,1,'5 sur 4272 depto 2304A','arq_ggodoy@yahoo.com','','977641575',5,'2021-02-26','2021-02-28','15:00','12:00',2,1,4,'PA'),(129,'2021-02-19 13:44:46','4','A','P',119,38,'116199645','Ubaldo Elias','Ferruzola ','Porra',38,1,3,2,' Los nogales 2931 ','ubaldo1968@hotmail.com','','996585637',2,'2021-03-01','2021-03-06','15:00','12:00',3,1,4,'PA'),(131,'2021-02-22 13:58:10','4','A','P',121,38,'105725558','Claudio ','Bahamondes','',38,1,3,1,' avenida costanera 3524 casa 48','bahamondes_claudio@hotmail.com','','979699822',6,'2021-02-27','2021-02-28','15:00','12:00',4,4,4,'PA'),(132,'2021-02-22 14:00:54','4','A','P',122,38,'160562641','Samanta','Cortes','Ramirez',38,1,3,1,'Pasaje Ruben Donoso 2982 depto 10','samanta.c.r@gmailcom','','999090757',1,'2021-02-27','2021-02-28','15:00','12:00',2,2,4,'PA'),(134,'2021-02-23 17:23:31','4','A','P',126,38,'15689847k','Alejandrs','Castillo','Contreras',38,2,5,8,' libertad 3033','alejandracastillo2411@gmail.com','','950919690',3,'2021-03-01','2021-03-04','15:00','12:00',2,3,2,'PA'),(135,'2021-02-23 17:25:54','4','A','P',72,38,'167724531','Yoceling','Alfaro','',38,1,3,NULL,' serrano 2050','yoceling.alfaro@gmail.com','','952145670',1,'2021-03-05','2021-03-06','15:00','12:00',2,2,4,'PA'),(136,'2021-02-23 17:28:32','4','A','P',127,38,'16437338k','Jonatan Andres ','Alvarez','Espinoza',38,2,5,8,'curico 2650','jonatan.alvarez.alon@gmail.com','','964481311',6,'2021-03-01','2021-03-02','15:00','12:00',6,0,4,'PP'),(137,'2021-02-24 12:54:41','4','A','P',128,38,'156422657','Gisselle','Chaparro','Rivera',38,1,3,1,'salvador allende 555 torre A depto 154 condominio portada or','ikelmito@gmail.com','','967387626',3,'2021-03-10','2021-03-11','15:00','12:00',2,3,4,'PA'),(139,'2021-03-02 11:34:54','4','A','P',130,38,'147422970','Rudy','Quevedo','',38,1,3,1,'','kizzy.rojas@hotmail.co','','948841569',5,'2021-03-02','2021-03-03','15:00','12:00',2,2,4,'PA'),(140,'2021-03-02 12:22:07','4','A','P',132,38,'209628163','Isabel','Imbarack','',38,15,1,343,'jose joaquin 837','isaimbarack@hotmail.com','','964175514',8,'2021-03-02','2021-03-03','15:00','12:00',2,2,4,'PA'),(141,'2021-03-02 12:24:38','4','A','P',111,38,'75777884',' syliva ','Rosas',' Urra',38,1,3,1,'grumete bolados 168 ','pivyta@gmail.com','','956983397',7,'2021-03-02','2021-03-02','14:00','12:00',1,0,4,'PA'),(142,'2021-03-04 09:30:38','4','A','P',133,38,'174319677','Yesenia ','Borquez ','Sandoval',38,1,3,2,' Avenida iquique 35','ronnysilva69@gmail.com','','975712208',6,'2021-03-03','2021-03-03','15:00','12:00',2,2,4,'PA'),(143,'2021-04-04 22:38:40','4','A','P',134,38,'19179189-','Brandon ','Mamani','',38,1,4,3,'Sillajuay 520','brandonbreimom.m@gmail.com','','958481967',5,'2021-04-09','2021-04-10','15:00','12:00',2,2,4,'PA'),(144,'2021-04-05 09:22:46','4','A','P',135,38,'188827888','Juan Carlos','Vasquez','',38,1,3,1,'Pasaje Sibaya 2272','juancarvato2015@gmail.com',' ','988943646',3,'2021-04-07','2021-04-08','15:00','12:00',3,1,4,'PA'),(145,'2021-04-06 21:16:14','4','A','P',136,38,'16614647k','Maritza ','Mamani','Garcia',38,1,3,2,' los condores 1957','susanamamani25@gmail.com','','945886362',2,'2021-04-08','2021-04-10','15:00','12:00',2,3,4,'PA'),(146,'2021-04-06 21:18:01','4','A','P',137,38,'0000000-9','Rosana ','Pizarro','',38,1,3,1,'','contacto@kiwiland.cl','','974603780',4,'2021-04-06','2021-04-08','15:00','12:00',2,0,3,'PA'),(147,'2021-04-09 13:02:28','4','A','P',138,38,'177999180','Luis Alberto','Linares','Catalan',38,1,4,3,'calle 2 numero 274 ','luis23linaresc@gmail.com','','937822342',6,'2021-04-09','2021-04-10','15:00','12:00',7,2,4,'PA'),(148,'2021-04-11 23:01:38','4','A','P',72,38,'16772453-','Yoceling','Alfaro','Arias',38,15,1,343,' colina 1918','yoceling.alfaro@gmail.com','','952145670',5,'2021-04-23','2021-04-24','14:00','12:00',2,2,4,'PA'),(149,'2021-04-11 23:03:39','4','A','P',139,38,'24208084-','Karimdad','Jalandari','',38,1,3,1,' capitan roberto perez 2777','norhpacif878@gmail.com','','984029394',3,'2021-04-09','2021-04-10','14:00','12:00',4,0,4,'PA'),(150,'2021-04-15 10:18:27','4','A','P',140,38,'161351172','Paz','Gonzalez','',38,1,3,2,'Michielle Bachelet 3750','violeta.24mp@gmail.com','','968700894',3,'2021-04-16','2021-04-17','15:00','12:00',2,1,4,'PA'),(152,'2021-04-18 21:23:56','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',4,'2021-04-16','2021-04-17','14:00','12:00',2,3,4,'PA'),(153,'2021-04-18 21:28:30','4','A','P',142,38,'182627720','Daniela','Rodriguez','',38,1,4,6,' Santa Rosa 4220','danii.rodriguez@icloud.com','','963910257',6,'2021-04-17','2021-04-17','14:00','12:00',4,5,4,'PA'),(154,'2021-04-20 18:47:21','4','A','P',143,38,'105024916','Alejandro ','Vera','',38,1,3,1,' av diagonal sur 4245','avjofre@hotmail.com','','983620209',3,'2021-04-23','2021-04-24','15:00','12:00',7,0,4,'PA'),(155,'2021-04-23 09:25:13','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',4,'2021-04-23','2021-04-29','14:00','12:00',2,0,4,'PA'),(156,'2021-04-25 11:58:47','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',2,'2021-04-24','2021-04-24','14:00','12:00',4,0,4,'PA'),(157,'2021-04-28 10:14:11','4','A','P',145,38,'17431300-','Valeria','Nievas','',38,1,3,1,'','nievas1990@gmail.com','','971811335',5,'2021-05-01','2021-05-01','15:00','12:00',2,2,4,'PA'),(158,'2021-04-28 10:16:03','4','A','P',146,38,'17726149-','Alexis','Ramos','',38,2,5,9,'fertilizantes702','alexis.ramos.91@outlook.com','','985021584',5,'2021-04-29','2021-04-30','15:00','12:00',2,0,4,'PA'),(159,'2021-04-28 10:21:09','4','A','P',147,38,'178012363','Francisca','Suarez','Ruiz',38,1,3,2,'pasaje rio valdivia 3025','francisca.suarezruiz@gmail.com','','998006009',4,'2021-04-30','2021-05-01','15:00','12:00',2,1,4,'PA'),(160,'2021-04-28 10:25:08','4','A','P',148,38,'165508602','brian','Espinoza','',38,1,3,1,'tadeo haenke 2526','contacto@kiwiland.cl','','953946395',6,'2021-04-30','2021-05-01','15:00','12:00',2,3,4,'PA'),(161,'2021-04-28 10:27:18','4','A','P',149,38,'188966926','Nycol','Muñoz','',38,1,3,1,'','nycol.mr@gmail.com','','986867575',1,'2021-04-30','2021-05-01','15:00','12:00',4,0,3,'PA'),(162,'2021-04-28 10:28:42','4','A','P',150,38,'180040161',' Juan Carlos','Amaya','',38,1,3,1,'','jcamaya23@gmail.com','','956694957',2,'2021-04-30','2021-05-01','15:00','12:00',4,0,3,'PA'),(163,'2021-05-02 16:41:45','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',4,'2021-05-20','2021-05-21','15:00','12:00',2,3,4,'PA'),(164,'2021-05-02 16:44:34','4','A','P',151,38,'199786903','Barbara','Challapa','',38,1,3,1,'coquimbo 2264','b.andreachallapa@outlook.com','','937592881',2,'2021-05-07','2021-05-08','15:00','12:00',3,1,3,'PA'),(165,'2021-05-02 16:46:43','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',3,'2021-04-30','2021-05-09','14:00','12:00',2,0,4,'PA'),(168,'2021-05-04 08:40:14','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',5,'2021-05-03','2021-05-03','14:00','12:00',1,0,4,'PA'),(169,'2021-05-05 09:05:36','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',6,'2021-05-04','2021-05-04','15:00','12:00',6,0,4,'PA'),(172,'2021-05-10 12:40:18','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',1,'2021-05-07','2021-05-08','14:00','12:00',4,0,4,'PA'),(173,'2021-05-10 12:42:31','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',8,'2021-05-07','2021-05-08','14:00','12:00',4,0,4,'PA'),(174,'2021-05-10 12:45:51','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',6,'2021-05-07','2021-05-08','14:00','12:00',4,2,4,'PA'),(175,'2021-05-10 12:47:40','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',3,'2021-05-10','2021-05-12','14:00','12:00',2,0,4,'PA'),(180,'2021-09-23 06:59:21','4','A','P',154,38,'17017258-','Daniza ','Callejas','Olivares',38,1,3,1,'Padre Hurtado 2389 depto 1703','danizaelizabeth@gmail.com','','947714442',8,'2021-10-01','2021-10-03','15:00','12:00',3,0,4,'PP'),(181,'2021-09-23 07:01:53','4','A','P',36,38,'17017258-','Daniza ','Callejas','Olivares',38,1,3,1,'Padre Hurtado 2389 depto 1703','danizaelizabeth@gmail.com','','947714442',1,'2021-10-01','2021-10-03','15:00','12:00',3,0,4,'PP'),(182,'2021-09-23 07:03:19','4','A','P',155,38,'17017258-','Daniza ','Callejas','Olivares',38,1,3,1,'Padre Hurtado 2389 depto 1703','danizaelizabeth@gmail.com','','947714442',2,'2021-10-01','2021-10-03','15:00','12:00',2,2,4,'PP'),(183,'2021-09-23 07:04:49','4','A','P',156,38,'170172582','Daniza ','Callejas','Olivares',38,1,3,1,'Padre Hurtado 2389 depto 1703','danizaelizabeth@gmail.com','','947714442',7,'2021-10-01','2021-10-03','15:00','12:00',3,0,4,'PP'),(184,'2021-09-24 13:07:37','4','A','P',157,38,'161502200','Francisca','Saavedra','Lopez',38,1,3,1,'Chipana 2040','saavedra_francisca@hotmail.com','','966179258',3,'2021-10-01','2021-10-03','15:00','12:00',2,2,4,'PP'),(185,'2021-09-24 13:08:50','4','A','P',158,38,'161502200','Francisca','Saavedra','Lopez',38,1,3,1,'Chipana 2040','saavedra_francisca@hotmail.com','','966179258',4,'2021-10-01','2021-10-03','15:00','12:00',2,2,4,'PP'),(186,'2021-09-24 13:10:48','4','A','P',159,38,'161502200','Francisca','Saavedra','Lopez',38,1,3,1,'Chipana 2040','saavedra_francisca@hotmail.com','','966179258',5,'2021-10-01','2021-10-03','15:00','12:00',2,2,4,'PP'),(187,'2021-09-24 13:15:12','4','A','P',160,38,'146056989','Joscelyne ','Parra','Santos',38,1,3,2,'','joscelyneparra@gmail.com','','989229219',6,'2021-10-01','2021-10-03','15:00','12:00',2,2,4,'PP'),(188,'2021-09-24 13:17:46','4','A','P',161,38,'118308441','Richard','Delgado ','Hidalgo',38,1,3,1,'2 oriente 4833','richardd012011@gmail.com','','944699963',1,'2021-10-08','2021-10-10','15:00','12:00',2,0,4,'PP'),(189,'2021-09-24 13:19:39','4','A','P',162,38,'156802964','Evelyn ','Caimanque','Martinez',38,1,3,2,'Hospicio Rio Bio Bio 3025','eve515caimanque@gmail.com','','987415851',6,'2021-10-08','2021-10-10','15:00','12:00',3,2,4,'PP'),(190,'2021-09-24 13:21:21','4','A','P',163,38,'156802964','Evelyn ','Caimanque','Martinez',38,1,3,2,'Alto Hospicio Rio Bio Bio','eve515caimanque@gmail.com','','987415851',7,'2021-10-08','2021-10-10','15:00','12:00',4,1,4,'PP'),(191,'2021-09-24 13:23:33','4','A','P',164,38,'147422970','Rudy Andrian','Quevedo','Hayan',38,1,3,1,'','quevedohuayan@gmail.com','','948841569',5,'2021-10-09','2021-10-11','15:00','12:00',2,1,4,'PP'),(192,'2021-09-24 13:25:12','4','A','P',165,38,'22906214K','Yelitza','Huayan','Guzman',38,1,3,1,'','quevedohuayan@gmail.com','','948841569',4,'2021-10-09','2021-10-11','14:00','12:00',3,2,4,'PP'),(193,'2021-09-24 13:27:23','4','A','P',166,38,'132440379','Erika','Silva','Cuzmar',38,4,11,26,'Veneto 404','erisicu@hotmail.com','','957882699',7,'2021-10-15','2021-10-18','15:00','12:00',5,0,4,'PP'),(194,'2021-09-25 20:55:12','4','A','P',168,38,'126973500','Luis','Rojas','Gutierrez',38,1,3,1,'Condominio La Tirana calle D casa 102','luisrojasgutierrez@gmail.com','','959258736',3,'2021-12-26','2021-12-28','15:00','12:00',4,0,4,'PP'),(195,'2021-09-30 22:03:57','4','A','P',170,38,'52525772','Alejandro','Acuña','Paez',38,2,7,15,'cienfuegos 1601','acunapaez@gmail.com','','998660269',8,'2021-10-08','2021-10-11','15:00','12:00',4,1,4,'PP'),(196,'2021-09-30 22:06:36','4','A','P',101,38,'52525772','Alejandro ','Acuña','Paez',38,2,7,15,'cienfuegos 1601','acunapaez@gmail.com','','998660269',2,'2021-10-08','2021-10-11','15:00','12:00',4,2,4,'PP'),(197,'2021-09-30 22:09:13','4','A','P',171,38,'199762613','domenika','larco','toledo',38,1,3,1,'pasaje tres islas 3617','domenikalarcotoledo@outlook.cl','','985053263',3,'2021-10-08','2021-10-11','15:00','12:00',6,1,4,'PP'),(198,'2021-10-03 22:39:44','4','A','P',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',8,'2021-10-04','2021-10-04','14:00','12:00',2,0,4,'PA'),(199,'2021-10-04 21:31:26','4','A','P',172,38,'16436111-','Felipe ','Tudela','',38,2,5,8,'Pisana 690','felipe.t.tudela@gmail.com','','957206811',4,'2021-10-08','2021-10-08','15:00','12:00',5,2,4,'PP'),(200,'2021-10-04 21:44:34','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',10,'2021-10-03','2021-10-03','14:00','17:00',4,0,4,'PA'),(201,'2021-10-04 21:46:41','4','A','E',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',9,'2021-10-03','2021-10-03','14:00','12:00',6,0,4,'PA'),(202,'2021-10-05 21:11:03','4','A','P',173,38,'158127342','Carolina','Arriagada','Maluenda',38,2,5,8,'Santiago Humberstone 125','carolinaarriagadamaluenda@gmail.com','','993808433',6,'2021-10-29','2021-11-01','15:00','12:00',6,2,4,'PP'),(203,'2021-10-05 21:13:46','4','A','P',174,38,'124193915','Ximena ','Ahumada','',38,2,5,8,'','ximeaaa@gmail.com','','932225657',3,'2021-10-06','2021-10-07','15:00','12:00',4,1,4,'PP'),(204,'2021-10-05 21:14:59','4','A','P',10,38,'761782703','Sociedad Inmobiliaria Kiwiland LTDA',' Inmobiliaria ','',38,1,3,1,'','contacto@kiwiland.cl','','993592555',9,'2021-10-04','2021-10-04','14:00','12:00',7,0,4,'PA');
/*!40000 ALTER TABLE `tbl_res_reservas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'qmo_kiwiland'
--

--
-- Dumping routines for database 'qmo_kiwiland'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-07  9:48:18
